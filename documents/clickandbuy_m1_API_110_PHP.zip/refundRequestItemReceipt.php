<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

session_start();
include('cabFunctions.php');

$itemArr = array();
$items = array();

$_SESSION['merchantID'] = $_POST['merchantID'];
$_SESSION['projectID'] = $_POST['projectID'];
$_SESSION['secretKey'] = $_POST['secretKey'];
	
$action = empty($_POST['action']) ? $_GET['action'] : $_POST['action']; 
$batchID = empty($_POST['batchID']) ? $_GET['batchID'] : $_POST['batchID'];
$itemNo = empty($_POST['itemNo']) ? $_GET['itemNo'] : $_POST['itemNo'];	

if (empty($batchID)) $batchID = 0;
$redirectUrl = 'refundRequestBatch.php?batchID='.$batchID;

if($action == 'deleteItem') {
	unset($_SESSION['refundItemList'][$batchID][$itemNo]);
} else {		
	$count = count($_SESSION['refundItemList'][$batchID]);
	$pos = $count+1;		

	$itemArr['pos'] = $pos;
	$itemArr['batchItemExternalID'] = $_POST['batchItemExternalID'];
	$itemArr['amount'] = $_POST['amount'];
	$itemArr['currency'] = $_POST['currency'];	
	$itemArr['transactionID'] = $_POST['transactionID'];
	$itemArr['externalID'] = $_POST['externalID'];
	$itemArr['orderDescription'] = $_POST['orderDescription'];		
	
	// Prepare items from Order Details
	for($i=1;$i<=3;$i++) {	
		$item = 'item'.$i;
		$itemType = $_POST[$item.'ItemType'];		
		$items[$i]['itemType'] = $itemType;	
	
		if($itemType == $item.'Text') {
			$items[$i]['textItemDescription'] = $_POST[$item.'TextItemDescription'];			
		} elseif($itemType == $item.'Item') {
			$items[$i]['itemDescription'] = $_POST[$item.'ItemDescription'];	
			$items[$i]['itemQuantity'] = $_POST[$item.'ItemQuantity'];	
			$items[$i]['itemUnitPriceAmount'] = $_POST[$item.'ItemUnitPriceAmount'];	
			$items[$i]['itemUnitPriceCurrency'] = $_POST[$item.'ItemUnitPriceCurrency'];	
			$items[$i]['itemTotalPriceAmount'] = $_POST[$item.'ItemTotalPriceAmount'];	
			$items[$i]['itemTotalPriceCurrency'] = $_POST[$item.'ItemTotalPriceCurrency'];				
		} elseif($itemType == $item.'Subtotal') {
			$items[$i]['subtotalItemDescription'] = $_POST[$item.'SubtotalItemDescription'];	
			$items[$i]['subtotalItemTotalPriceAmount'] = $_POST[$item.'SubtotalItemTotalPriceAmount'];	
			$items[$i]['subtotalItemTotalPriceCurrency'] = $_POST[$item.'SubtotalItemTotalPriceCurrency'];	
		} elseif($itemType == $item.'Vat') {
			$items[$i]['vatItemDescription'] = $_POST[$item.'VatItemDescription'];	
			$items[$i]['vatItemTotalPriceAmount'] = $_POST[$item.'VatItemTotalPriceAmount'];	
			$items[$i]['vatItemTotalPriceCurrency'] = $_POST[$item.'VatItemTotalPriceCurrency'];	
		} elseif($itemType == $item.'Total') {
			$items[$i]['totalItemDescription'] = $_POST[$item.'TotalItemDescription'];	
			$items[$i]['totalItemTotalPriceAmount'] = $_POST[$item.'TotalItemTotalPriceAmount'];	
			$items[$i]['totalItemTotalPriceCurrency'] = $_POST[$item.'TotalItemTotalPriceCurrency'];	
		}					
	}
		
	$items = call_user_func('removeEmptyTag',$items);	
	$itemArr['itemDetailList'] = $items;	 
	
  $_SESSION['refundItemList'][$batchID][$pos] = $itemArr;
}

header("Location: $redirectUrl");
exit();		
	
?>