<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabConstants.php');	
include('cabFunctions.php');

$statusType = $_GET['statusType'];

if (empty($statusType)) 
	$statusType = 'transactionID';
	

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - StatusRequest</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>

<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="100%" align="center" class="headlogo">ClickandBuy - StatusRequest</td>
  <td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
</tr>
</table>	
	
<form action="statusRequestReceipt.php" method="POST" >
<input type="hidden" name="statusType" value="<?php echo $statusType; ?>"/>
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">Merchant Info</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
		<tr>
	  	<td width="200">Merchant ID:</td>
	    <td><input type="text" name="merchantID" value="<?php echo MERCHANT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
		</tr>		
	  <tr>
	  	<td>Project ID:</td>
	    <td><input type="text" name="projectID" value="<?php echo PROJECT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
		</tr>		
	  <tr>
	  	<td>Secret Key:</td>
	    <td><input type="text" name="secretKey" value="<?php echo SECRET_KEY; ?>" /></td>
		</tr>		    
		</table>&nbsp;
	</td>
</tr>
<?php if($statusType == 'transactionID') { ?>
<tr>
	<td colspan="2" class="head1">Status Request Details &gt;&gt; <a href="statusRequest.php?statusType=externalID">Show ExternalID Details</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
		<tr>
	  	<td width="200">Transaction ID 1: </td>
	    <td><input type="text" name="transactionID1" value="" /></td>
		</tr>	    			
		</table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Multiple Items &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Transaction ID 2: </td>
	    <td><input type="text" name="transactionID2" value="" /></td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
    </tr>   
    <tr>
	    <td>Transaction ID 3: </td>
	    <td colspan="2"><input type="text" name="transactionID3" value="" /></td>
    </tr>   
    <tr>
	    <td>Transaction ID 4: </td>
	    <td colspan="2"><input type="text" name="transactionID4" value="" /></td>
    </tr>   
    <tr>
	    <td>Transaction ID 5: </td>
	    <td colspan="2"><input type="text" name="transactionID5" value="" /></td>
    </tr>   
    </table>
    </div>&nbsp;
	</td>
</tr>  
<?php } else { ?>
<tr>
	<td colspan="2" class="head1">Status Request Details &gt;&gt; <a href="statusRequest.php">Show Transaction Details</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
		<tr>
	  	<td width="200">External ID 1: </td>
	    <td><input type="text" name="externalID1" value="" /></td>
		</tr>	    			
		</table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Multiple Items &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">External ID 2: </td>
	    <td><input type="text" name="externalID2" value="" /></td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
    </tr>   
    <tr>
	    <td>External ID 3: </td>
	    <td colspan="2"><input type="text" name="externalID3" value="" /></td>
    </tr>   
    <tr>
	    <td>External ID 4: </td>
	    <td colspan="2"><input type="text" name="externalID4" value="" /></td>
    </tr>   
    <tr>
	    <td>External ID 5: </td>
	    <td colspan="2"><input type="text" name="externalID5" value="" /></td>
    </tr>   
    </table>
    </div>&nbsp;
	</td>
</tr>  
<?php } ?>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td width="200">&nbsp;</td>
		  <td><input type="submit" name="submit" value="Submit" /></td>
		</tr>
		</table>
	</td>
</tr>      
</table>
</form>

</center>
</body>
</html>