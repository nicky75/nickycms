<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabConstants.php');	
include('cabFunctions.php');	

$xml = $_POST['xml'];
$sendEmailTo = MMS_EMAIL_TO;
$sendEmailFrom = MMS_EMAIL_FROM;
$mmsSecretKey = MMS_SECRET_KEY;

if(checkSignature($xml,$mmsSecretKey) != true) {
	die('Signature check failed');	
}

if(MMS_LOG) {
	logMmsEvent($xml);	
}

if(!empty($sendEmailTo) && !empty($sendEmailFrom)) {
	sendMail($sendEmailTo,$sendEmailFrom,$xml);		
}

$xmlArray = parseXML($xml);

$eventAmt = $xmlArray['EVENTLIST']['HEADER']['event-amt'];

$eventType = array('payEvent', 'refundEvent', 'creditEvent', 'recurringPaymentAuthorizationEvent', 'batchEvent');

foreach ($eventType as $key) {
	$eventList =  $xmlArray['EVENTLIST'][$key];

	if (!empty($eventList)) {
		call_user_func($key.'List',$eventList);		
	}	
}

/*
 * Giving the response to the ClickandBuy Payment System
 */
 echo 'OK';
