<?php 
	// (Re-)Start Session
	session_start();

	// Setting API 1.0.0 as default if nothing else is known
	if ($_SESSION['apiVersion'] == '') {
		//echo 'Keine API Version in Session gesetzt!';
		$_SESSION['apiVersion'] = '1.0.0';
	}

	// Check for user selection of API version and store in Session
	if ($_POST['apiVersion'] == '1.0.0') {
		$_SESSION['apiVersion'] = '1.0.0';
	}
	else if ($_POST['apiVersion'] == '1.1.0') {
		$_SESSION['apiVersion'] = '1.1.0';
	}
?>
<html>
	<!-- Begin HTML Head -->
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>ClickandBuy PHP Samples Main Page</title>
		<link href="include/style.css" rel="stylesheet" type="text/css" />
		<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
	</head>
	<!-- Begin HTML Body -->
	<body>
		<center>
			<table width="980" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
					<td width="100%" align="center" class="headlogo">ClickandBuy PHP Samples Main Page</td>
					<td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
				</tr>
			</table>	
			<br />
			<br />
			<form action="index.php" method="POST" >
				<table width="980" border="0" cellspacing="0" cellpadding="0">
					<tr>
						<td align="left"><b>Select API Version</b></td>
					</tr>
					<tr>
						<td width="5%" align="left">
							<select name="apiVersion" size="1">
								<option <?php if(($_SESSION["apiVersion"]) == "1.0.0") echo "selected"; ?> value="1.0.0">v1.0.0</option>
								<option <?php if(($_SESSION["apiVersion"]) == "1.1.0") echo "selected"; ?> value="1.1.0">v1.1.0</option>
							</select>
							&nbsp;
							<input type="submit" name="apiSelector" value="Set" />
						</td>
					</tr>
				</table>
			</form>
			<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
				<tr>
					<td class="head1" colspan="2" >Transaction Calls</td>
				</tr>	    	
				<tr>
					<td width="50" class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="payRequest.php">Pay Request</a></td>
				</tr>		
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="payRequestRecurring.php">Pay Request Recurring</a></td>
				</tr>		
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="refundRequest.php">Refund Request</a></td>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<?php
						if ($_SESSION["apiVersion"] == "1.0.0") {
							// API 1.0.0 selection
							echo '<td class="idxtd"><a href="cancelRequest.php">Cancel Request</a></td>';
						} else if ($_SESSION["apiVersion"] == "1.1.0") {
							// API 1.1.0 selection
							echo '<td class="idxtd"><a href="cancelRequest110.php">Cancel Request (API v.1.1.0)</a></td>';
						}
					?>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<?php
						if ($_SESSION["apiVersion"] == "1.0.0") {
							// API 1.0.0 selection
							echo '<td class="idxtd"><a href="creditRequest.php">Credit Request</a></td>';
						} else if ($_SESSION["apiVersion"] == "1.1.0") {
							echo '<td class="idxtd"><a href="creditRequest110.php">Credit Request (API v1.1.0)</a></td>';
						}
					?>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="statusRequest.php">Status Request</a></td>
				</tr>
				<?php
					if ($_SESSION["apiVersion"] == "1.1.0") {
						echo '<tr><td class="head1" colspan="2">Accounting</td></tr><tr><td class="idxtd">&nbsp;</td><td class="idxtd">';
						echo '<a href="getAccountingDocumentsRequest110.php">Get Accounting Documents (API 1.1.0)</a></td></tr>';
					}
				?>
				<tr>
					<td class="head1" colspan="2">Batch Calls</td>
				</tr>	    	
				<tr>
					<td width="50" class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="createBatch.php">Create Batch</a></td>
				</tr>		
				<tr>
					<td width="50" class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="payRequestBatch.php">Add Batch Item - Pay Request</a></td>
				</tr>		
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="recurringBatch.php">Add Batch Item - Pay Request Recurring</a></td>
				</tr>		
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="refundRequestBatch.php">Add Batch Item - Refund Request</a></td>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<?php
						if ($_SESSION["apiVersion"] == "1.0.0") {
							// API 1.0.0 selection
							echo '<td class="idxtd"><a href="cancelRequestBatch.php">Add Batch Item -  Cancel Request</a></td>';
						} else if ($_SESSION["apiVersion"] == "1.1.0") {
							echo '<td class="idxtd"><a href="cancelRequestBatch110.php">Add Batch Item -  Cancel Request (API v.1.1.0)</a></td>';
						}
					?>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<?php
						if ($_SESSION["apiVersion"] == "1.0.0") {
							// API 1.0.0 selection
							echo '<td class="idxtd"><a href="creditRequestBatch.php">Add Batch Item -  Credit Request</a></td>';
						} else if ($_SESSION["apiVersion"] == "1.1.0") {
							echo '<td class="idxtd"><a href="creditRequestBatch110.php">Add Batch Item -  Credit Request (API v.1.1.0)</a></td>';
						}
					?>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="executeBatch.php">Execute Batch</a></td>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="getBatchStatus.php">Get Batch Status</a></td>
				</tr>		    
				<tr>
					<td class="idxtd">&nbsp;</td>
					<td class="idxtd"><a href="cancelBatch.php">Cancel Batch</a></td>
				</tr>    
			</table>	
		</center>
	</body>
</html>
<?php ?>
    