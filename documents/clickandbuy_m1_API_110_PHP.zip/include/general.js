function toggledisplay (id){
	if (document.getElementById) {
	    var mydiv = document.getElementById(id);
	    mydiv.style.display = (mydiv.style.display=='block'?'none':'block');
	}
}

function ShowAndHideOthersItem1( value ) {
    var ids = [ "item1Text", "item1Item", "item1Subtotal", "item1Vat", "item1Total" ];
    for( var i = 0; i < ids.length; i++ ) {
      var obj = document.getElementById( ids[i] );
      if( obj )
        obj.style.display = (value == ids[i]) ? "block" : "none";
    }
}

function ShowAndHideOthersItem2( value ) {
    var ids = [ "item2Text", "item2Item", "item2Subtotal", "item2Vat", "item2Total" ];
    for( var i = 0; i < ids.length; i++ ) {
      var obj = document.getElementById( ids[i] );
      if( obj )
        obj.style.display = (value == ids[i]) ? "block" : "none";
    }
}

function ShowAndHideOthersItem3( value ) {
    var ids = [ "item3Text", "item3Item", "item3Subtotal", "item3Vat", "item3Total" ];
    for( var i = 0; i < ids.length; i++ ) {
      var obj = document.getElementById( ids[i] );
      if( obj )
        obj.style.display = (value == ids[i]) ? "block" : "none";
    }
}

function ShowAndHideBillingCompany( value ) {
    var ids = [ "billingConsumer", "billingCompany" ];
    for( var i = 0; i < ids.length; i++ ) {
      var obj = document.getElementById( ids[i] );
      if( obj )
        obj.style.display = (value == ids[i]) ? "block" : "none";
    }
}

function ShowAndHideShippingCompany( value ) {
    var ids = [ "shippingConsumer", "shippingCompany" ];
    for( var i = 0; i < ids.length; i++ ) {
      var obj = document.getElementById( ids[i] );
      if( obj )
        obj.style.display = (value == ids[i]) ? "block" : "none";
    }
}

function AllowNumericOnly(e)
{
	e = ( e ) ? e : window.event
	var charCode = ( e.which ) ? e.which : e.keyCode

	if ( charCode == 46) {
		return true
	}
	
	if ( charCode > 31 && ( charCode < 48 || charCode > 57 )) {
		return false
	}
	return true
}
