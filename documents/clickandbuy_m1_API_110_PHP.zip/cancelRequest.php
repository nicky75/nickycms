<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabConstants.php');	
include('cabFunctions.php');	

$externalID = substr(md5(uniqid(rand())),0,12);  

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - CancelRequest</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>

<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="100%" align="center" class="headlogo">ClickandBuy - CancelRequest</td>
  <td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
</tr>
</table>	

<form action="cancelRequestReceipt.php" method="POST" >
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
  <td colspan="2" class="head1">Merchant Info</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Merchant ID:</td>
	    <td><input type="text" name="merchantID" value="<?php echo MERCHANT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>		
    <tr>
    	<td>Project ID:</td>
    	<td><input type="text" name="projectID" value="<?php echo PROJECT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>		
    <tr>
    	<td>Secret Key:</td>
    	<td><input type="text" name="secretKey" value="<?php echo SECRET_KEY; ?>" /></td>
    </tr>		    
    </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Cancel Request Details  </td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
 	  <tr>
    	<td width="200">Transaction ID: </td>
    	<td><input type="text" name="transactionID" value="" /></td>
    </tr>	    	
    </table>&nbsp;
	</td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
	<table width="680" border="0"" cellspacing="0" cellpadding="0">
	<tr>
		<td width="200">&nbsp;</td>
		<td><input type="submit" name="submit" value="Submit" /></td>
	</tr>
  </table>
	</td>
</tr>        
</table>
</form>

</center>
</body>
</html>