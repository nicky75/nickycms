<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabConstants.php');	
include('cabFunctions.php');

session_start();

$batchID = $_GET['batchID'];	

$merchantID = $_POST['merchantID'];
$projectID = $_POST['projectID'];
$secretKey = $_POST['secretKey'];

$_SESSION['merchantID'] = $merchantID;
$_SESSION['projectID'] = $projectID;
$_SESSION['secretKey'] = $secretKey;
	
$merchantID = !empty($_SESSION['merchantID']) ? $_SESSION['merchantID'] : MERCHANT_ID;
$projectID = !empty($_SESSION['projectID']) ? $_SESSION['projectID'] : PROJECT_ID; 
$secretKey = !empty($_SESSION['secretKey']) ? $_SESSION['secretKey'] : SECRET_KEY; 

$externalID = substr(md5(uniqid(rand())),0,12);  

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - AddBatchItem PayRequest</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>

<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="100%" align="center" class="headlogo">ClickandBuy - AddBatchItem PayRequest</td>
  <td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
</tr>
</table>	
	
<form action="payRequestItemReceipt.php" method="POST" >
<input type="hidden" name="action" value="addItem" />
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">Merchant Info</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td width="200">Merchant ID:</td>
    	<td><input type="text" name="merchantID" value="<?php echo $merchantID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>		
    <tr>
    	<td>Project ID:</td>
    	<td><input type="text" name="projectID" value="<?php echo $projectID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>		
    <tr>
    	<td>Secret Key:</td>
    	<td><input type="text" name="secretKey" value="<?php echo $secretKey; ?>" /></td>
    </tr>		    
    </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Add Batch Item Details</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td width="200">Batch ID:</td>
    	<td><input type="text" name="batchID" value="<?php if ($batchID != 0) echo $batchID; ?>" /></td>
		</tr>		
	  <tr>
    	<td width="200">Batch Item External ID:</td>
    	<td><input type="text" name="batchItemExternalID" value="" /></td>
    </tr>	    			
	  </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">PayRequest Details</td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td width="200">Amount: </td>
    	<td>
				<input name="amount" type="text"  value="1.00" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"> (1.00)
			</td>
		</tr>	    	
		<tr>
			<td>Currency: </td>
    	<td>
				<select name="currency" size="1">
		      <option value="EUR">EUR</option>
		      <option value="GBP">GBP</option>
		      <option value="USD">USD</option>
		    </select>
			</td>
    </tr>	     
    <tr>
    	<td>Basket Risk: </td>
    	<td><input type="text" name="basketRisk" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>	    	
    <tr>
    	<td>Client Risk: </td>
    	<td><input type="text" name="clientRisk" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>	    	
    <tr>
    	<td>Authentication Expiration: </td>
    	<td><input type="text" name="authExpiration" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>	    	
    <tr>
    	<td>Confirm Expiration: </td>
    	<td><input type="text" name="confirmExpiration" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>	    	
    <tr>
    	<td>Success Expiration: </td>
    	<td><input type="text" name="successExpiration" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>	    	
    <tr>
    	<td>Success URL: </td>
    	<td><input type="text" name="successURL" value="" /></td>
    </tr>	    	
    <tr>
    	<td>Failure URL: </td>
    	<td><input type="text" name="failureURL" value="" /></td>
    </tr>	    	
    <tr>
    	<td>ExternalID: </td>
    	<td><input type="text" name="externalID" value="<?php echo $externalID; ?>" /></td>
    </tr>	 	    	
    <tr>
    	<td>Consumer IP Address: </td>
    	<td><input type="text" name="consumerIPAddress" value="" /></td>
    </tr>	    	
    <tr>
    	<td>Consumer Language: </td>
    	<td>
    		<select name="consumerLanguage" size="1">
			  	<option value="" selected>--</option>
		      <option value="de">DE</option>
		      <option value="en">EN</option>
		      <option value="fr">FR</option>
		    </select>
			</td>
    </tr>		
    <tr>
    	<td>Consumer Nation: </td>
    	<td>
    		<select name="consumerNation" size="1">
		      <option selected value="">--</option>
		      <option value="DE">DE</option>
		      <option value="UK">UK</option>
		      <option value="US">US</option>
		    </select>
			</td>
		</tr>		
	  </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Order Details &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0" cellspacing="0" cellpadding="0">
   <!-- Item 1 -->
    <tr>
	    <td width="200">Item 1: </td>
	    <td>
				<select name="item1ItemType" id="itemType" onChange="ShowAndHideOthersItem1(this.value)">
					<option value="">Select Item Type</option>
					<option value="item1Text">TEXT</option>
					<option value="item1Item">ITEM</option>
					<option value="item1Subtotal">SUBTOTAL</option>
					<option value="item1Vat">VAT</option>
					<option value="item1Total">TOTAL</option>
				</select>
	    </td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 1 - text -->
				<div id="item1Text" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - item -->
				<div id="item1Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item1ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item1ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item1ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - subtotal -->
				<div id="item1Subtotal" style="display:none">
				<table width="680" border="0 cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - vat -->
				<div id="item1Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - total -->
				<div id="item1Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr>						
   	<!-- Item 2 -->
    <tr>
	    <td width="200">Item 2: </td>
	    <td colspan="2">
				<select name="item2ItemType" id="itemType" onChange="ShowAndHideOthersItem2(this.value)">
					<option value="">Select Item Type</option>
					<option value="item2Text">TEXT</option>
					<option value="item2Item">ITEM</option>
					<option value="item2Subtotal">SUBTOTAL</option>
					<option value="item2Vat">VAT</option>
					<option value="item2Total">TOTAL</option>
				</select>
	    </td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 2 - item -->
				<div id="item2Text" style="display:none">
				<table width="680" border="0"" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - item -->
				<div id="item2Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item2ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item2ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item2ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - subtotal -->
				<div id="item2Subtotal" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - vat -->
				<div id="item2Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - total -->
				<div id="item2Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr>
   <!-- Item 3 -->
    <tr>
	    <td width="200">Item 3: </td>
	    <td colspan="2">
				<select name="item3ItemType" id="itemType" onChange="ShowAndHideOthersItem3(this.value)">
					<option value="">Select Item Type</option>
					<option value="item3Text">TEXT</option>
					<option value="item3Item">ITEM</option>
					<option value="item3Subtotal">SUBTOTAL</option>
					<option value="item3Vat">VAT</option>
					<option value="item3Total">TOTAL</option>
				</select>
	    </td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 3 - text -->
				<div id="item3Text" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - item -->
				<div id="item3Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item3ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item3ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item3ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - subtotal -->
				<div id="item3Subtotal" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
			    </td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - vat -->
				<div id="item3Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - total -->
				<div id="item3Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr> 
		</table>
	  </div>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Shipping Address &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
	  <!-- Shipping Address -->
		<div id="divbox2" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Shipping Address Details: </td>
	    <td>
				<select name="shippingType" id="shippingType" onChange="ShowAndHideShippingCompany(this.value)">
					<option value="shippingConsumer">Consumer</option>
					<option value="shippingCompany">Company</option>
				</select>
	    </td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
    </tr>       
		</table>&nbsp;			
	  <!-- Shipping Address - Consumer -->
		<div id="shippingConsumer" style="display:block">
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Salutation: </td>
	    <td>
	    	<select name="shippingConsumerSalutation" size="1">
					<option value="" selected>--</option>
		      <option value="MR">Mr.</option>
		      <option value="MS">Ms.</option>
	    	</select>
			</td>
    </tr>
    <tr>
	    <td>Title: </td>
	    <td><input type="text" name="shippingConsumerTitle" value="" /></td>
    </tr>
    <tr>
	    <td>First Name: </td>
	    <td><input type="text" name="shippingConsumerFirstName" value="Marcus" /></td>
    </tr>
    <tr>
	    <td>Last Name: </td>
	    <td><input type="text" name="shippingConsumerLastName" value="Mustermann" /></td>
    </tr>
    <tr>
	    <td>Maiden Name: </td>
	    <td><input type="text" name="shippingConsumerMaidenName" value="" /></td>
    </tr>
    <tr>
	    <td width="200">Gender: </td>
	    <td>
	    	<select name="shippingConsumerGender" size="1">
					<option value="" selected>--</option>
		      <option value="MALE">Male</option>
		      <option value="FEMALE">Female</option>
	    	</select>
			</td>
    </tr>
    <tr>
	    <td>Date of Birth: </td>
	    <td><input type="text" name="shippingConsumerDateOfBirth" value="" /> (yyyy-mm-dd)</td>
    </tr>                
    <tr>
	    <td>Consumer Language Code: </td>
	    <td>
	    	<select name="shippingConsumerLanguage" size="1">
		      <option value="">--</option>
		      <option value="DE" selected>DE</option>
		      <option value="UK">UK</option>
		      <option value="US">US</option>
		    </select>
	    </td>
    </tr>
    <tr>
	    <td>Street: </td>
	    <td><input type="text" name="shippingConsumerStreet" value="Im Mediapark" /></td>
    </tr>
    <tr>
	    <td>House Number: </td>
	    <td><input type="text" name="shippingConsumerHouseNumber" value="5" /></td>
    </tr>
    <tr>
	    <td>House Number Suffix: </td>
	    <td><input type="text" name="shippingConsumerHouseNumberSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>Address Suffix: </td>
	    <td><input type="text" name="shippingConsumerAddressSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>ZIP Code: </td>
	    <td><input type="text" name="shippingConsumerZIP" value="50670" /></td>
    </tr>
    <tr>
	    <td>City: </td>
	    <td><input type="text" name="shippingConsumerCity" value="Koeln" /></td>
    </tr>
    <tr>
	    <td>State: </td>
	    <td><input type="text" name="shippingConsumerState" value="NRW" /></td>
    </tr>
    <tr>
	    <td>Country Code: </td>
	    <td>
	    	<select name="shippingConsumerCountry" size="1">
		      <option value="">--</option>
		      <option value="de" selected>DE</option>
		      <option value="uk">UK</option>
		      <option value="us">US</option>
		    </select>
	    </td>
    </tr>
		</table>
		</div>
	  <!-- Shipping Address - Company -->
		<div id="shippingCompany" style="display:none">
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Company Name: </td>
	    <td><input type="text" name="shippingCompanyName" value="Demo S-Company" maxlength="255" /></td>
    </tr>
    <tr>
	    <td>VAT ID: </td>
	    <td><input type="text" name="shippingCompanyVat" value="" /></td>
    </tr>
	    <tr>
		    <td>Registry ID: </td>
		    <td><input type="text" name="shippingCompanyRegistryID" value="" maxlength="255" /></td>
	    </tr>
	    <tr>
		    <td>Registry Zip Code: </td>
		    <td><input type="text" name="shippingCompanyRegistryZIP" value="" maxlength="255" /></td>
	    </tr>
	    <tr>
		    <td>Registry City: </td>
		    <td><input type="text" name="shippingCompanyRegistryCity" value="" maxlength="255" /></td>
	    </tr>
    <tr>
	    <td>Street: </td>
	    <td><input type="text" name="shippingCompanyStreet" value="Im Mediapark" /></td>
    </tr>
    <tr>
	    <td>House Number: </td>
	    <td><input type="text" name="shippingCompanyHouseNumber" value="5" /></td>
    </tr>
    <tr>
	    <td>House Number Suffix: </td>
	    <td><input type="text" name="shippingCompanyHouseNumberSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>Address Suffix: </td>
	    <td><input type="text" name="shippingCompanyAddressSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>ZIP Code: </td>
	    <td><input type="text" name="shippingCompanyZIP" value="50670" /></td>
    </tr>
    <tr>
	    <td>City: </td>
	    <td><input type="text" name="shippingCompanyCity" value="Koeln" /></td>
    </tr>
    <tr>
	    <td>State: </td>
	    <td><input type="text" name="shippingCompanyState" value="NRW" /></td>
    </tr>
    <tr>
	    <td>Country Code: </td>
	    <td>
	    	<select name="shippingCompanyCountry" size="1">
		      <option value="">--</option>
		      <option value="de" selected>DE</option>
		      <option value="uk">UK</option>
		      <option value="us">US</option>
		    </select>
	    </td>
    </tr>
		</table>
		</div>
		</div>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Billing Address &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox3'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
	  <!-- Billing Address -->
		<div id="divbox3" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Billing Address Details: </td>
	    <td>
				<select name="billingType" id="billingType" onChange="ShowAndHideBillingCompany(this.value)">
					<option value="billingConsumer">Consumer</option>
					<option value="billingCompany">Company</option>
				</select>
	    </td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox3'); return false" title="Hide">Hide</a></td>
    </tr>       
		</table>&nbsp;			
	  <!-- Billing Address - Consumer -->
		<div id="billingConsumer" style="display:block">
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Salutation: </td>
	    <td>
	    	<select name="billingConsumerSalutation" size="1">
					<option value="" selected>--</option>
		      <option value="MR">Mr.</option>
		      <option value="MS">Ms.</option>
	    	</select>
			</td>
    </tr>
    <tr>
	    <td>Title: </td>
	    <td><input type="text" name="billingConsumerTitle" value="" /></td>
    </tr>
    <tr>
	    <td>First Name: </td>
	    <td><input type="text" name="billingConsumerFirstName" value="Marcus" /></td>
    </tr>
    <tr>
	    <td>Last Name: </td>
	    <td><input type="text" name="billingConsumerLastName" value="Mustermann" /></td>
    </tr>
    <tr>
	    <td>Maiden Name: </td>
	    <td><input type="text" name="billingConsumerMaidenName" value="" /></td>
    </tr>
    <tr>
	    <td width="200">Gender: </td>
	    <td>
	    	<select name="billingConsumerGender" size="1">
					<option value="" selected>--</option>
		      <option value="MALE">Male</option>
		      <option value="FEMALE">Female</option>
	    	</select>
			</td>
    </tr>
    <tr>
	    <td>Date of Birth: </td>
	    <td><input type="text" name="billingConsumerDateOfBirth" value="" /> (yyyy-mm-dd)</td>
    </tr>                
    <tr>
	    <td>Consumer Language Code: </td>
	    <td>
	    	<select name="billingConsumerLanguage" size="1">
		      <option value="">--</option>
		      <option value="DE" selected>DE</option>
		      <option value="UK">UK</option>
		      <option value="US">US</option>
		    </select>
	    </td>
    </tr>
    <tr>
	    <td>Street: </td>
	    <td><input type="text" name="billingConsumerStreet" value="Im Mediapark" /></td>
    </tr>
    <tr>
	    <td>House Number: </td>
	    <td><input type="text" name="billingConsumerHouseNumber" value="5" /></td>
    </tr>
    <tr>
	    <td>House Number Suffix: </td>
	    <td><input type="text" name="billingConsumerHouseNumberSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>Address Suffix: </td>
	    <td><input type="text" name="billingConsumerAddressSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>ZIP Code: </td>
	    <td><input type="text" name="billingConsumerZIP" value="50670" /></td>
    </tr>
    <tr>
	    <td>City: </td>
	    <td><input type="text" name="billingConsumerCity" value="Koeln" /></td>
    </tr>
    <tr>
	    <td>State: </td>
	    <td><input type="text" name="billingConsumerState" value="NRW" /></td>
    </tr>
    <tr>
	    <td>Country Code: </td>
	    <td>
	    	<select name="billingConsumerCountry" size="1">
		      <option value="">--</option>
		      <option value="de" selected>DE</option>
		      <option value="uk">UK</option>
		      <option value="us">US</option>
		    </select>
	    </td>
    </tr>
		</table>
		</div>
	  <!-- Billing Address - Company -->
		<div id="billingCompany" style="display:none">
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
	    <td width="200">Company Name: </td>
	    <td><input type="text" name="billingCompanyName" value="Demo S-Company" maxlength="255" /></td>
    </tr>
    <tr>
	    <td>VAT ID: </td>
	    <td><input type="text" name="billingCompanyVat" value="" /></td>
    </tr>
	    <tr>
		    <td>Registry ID: </td>
		    <td><input type="text" name="billingCompanyRegistryID" value="" maxlength="255" /></td>
	    </tr>
	    <tr>
		    <td>Registry Zip Code: </td>
		    <td><input type="text" name="billingCompanyRegistryZIP" value="" maxlength="255" /></td>
	    </tr>
	    <tr>
		    <td>Registry City: </td>
		    <td><input type="text" name="billingCompanyRegistryCity" value="" maxlength="255" /></td>
	    </tr>
    <tr>
	    <td>Street: </td>
	    <td><input type="text" name="billingCompanyStreet" value="Im Mediapark" /></td>
    </tr>
    <tr>
	    <td>House Number: </td>
	    <td><input type="text" name="billingCompanyHouseNumber" value="5" /></td>
    </tr>
    <tr>
	    <td>House Number Suffix: </td>
	    <td><input type="text" name="billingCompanyHouseNumberSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>Address Suffix: </td>
	    <td><input type="text" name="billingCompanyAddressSuffix" value="" /></td>
    </tr>
    <tr>
	    <td>ZIP Code: </td>
	    <td><input type="text" name="billingCompanyZIP" value="50670" /></td>
    </tr>
    <tr>
	    <td>City: </td>
	    <td><input type="text" name="billingCompanyCity" value="Koeln" /></td>
    </tr>
    <tr>
	    <td>State: </td>
	    <td><input type="text" name="billingCompanyState" value="NRW" /></td>
    </tr>
    <tr>
	    <td>Country Code: </td>
	    <td>
	    	<select name="billingCompanyCountry" size="1">
		      <option value="">--</option>
		      <option value="de" selected>DE</option>
		      <option value="uk">UK</option>
		      <option value="us">US</option>
		    </select>
	    </td>
    </tr>
		</table>
		</div>
		</div>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Create Recurring Authorization Details &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox4'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox4" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td width="200">Description: </td>
	    <td><input type="text" name="recDescription" value="" /></td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox4'); return false" title="Hide">Hide</a></td>
		</tr>
    <tr>
	    <td>Number Limit: </td>
	    <td colspan="2"><input type="text" name="recNumberLimit" value="" onkeypress="return AllowNumericOnly(event);"/></td>
    </tr>
    <tr>
	    <td>Amount: </td>
	    <td colspan="2"><input name="recAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>
    </tr>
    <tr>
	    <td>Currency: </td>
	    <td colspan="2">
						<select name="recCurrency" size="1">
							<option value="">--</option>
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
			</td>
    </tr>
    <tr>
	    <td>Date Limit: </td>
	    <td colspan="2"><input type="text" name="recExpireDate" value="" /> (yyyy-mm-dd)</td>
    </tr>                
    <tr>
	    <td>Revokable By Consumer: </td>
	    <td colspan="2"><input type="checkbox" name="recRevokableByConsumer" value="true" /></td>
    </tr> 
	  </table>
	  </div>&nbsp;
	</td>
</tr>   
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td width="200">&nbsp;</td>
		  <td><input type="submit" name="submit" value="Add Item to Batch List" />
		</td>
		</tr>
		</table>
	</td>
</tr>
</table>
</form>
        
<?php if(!empty($_SESSION['payRequestItemList'][$batchID])) {	?>
<form action="payRequestBatchReceipt.php" method="POST" >
<input type="hidden" name="batchID" value="<?=$batchID;?>" />
<input type="hidden" name="merchantID" value="<?=$merchantID;?>" />
<input type="hidden" name="projectID" value="<?=$projectID;?>" />
<input type="hidden" name="secretKey" value="<?=$secretKey;?>" />
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">List of Batch Request Items</td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>		
		<table width="680" border="0" cellspacing="0" cellpadding="0" class="cab_table">
    <tr>
	    <td width="80"><strong>Item No</strong></td>
	    <td width="125"><strong>Amount</strong></td>
	    <td width="125"><strong>Currency</strong></td>
	    <td width="300"><strong>External ID</strong></td>
	    <td width="50"><strong>Action</strong></td>
		</tr>
		<?php foreach($_SESSION['payRequestItemList'][$batchID] as $key) { ?>
		<tr>
	    <td><?=$key['pos'];?></td>
	    <td><?=$key['amount'];?></td>
	    <td><?=$key['currency'];?></td>
	    <td><?=$key['externalID'];?></td>
	    <td><a href="payRequestItemReceipt.php?action=deleteItem&batchID=<?=$batchID;?>&itemNo=<?=$key['pos'];?>">Delete</a></td>
		</tr>
		<?php } ?>
	  </table>&nbsp;
	</td>
</tr>    
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
	    <td width="200">&nbsp;</td>
	    <td><input type="submit" name="submit" value="Add to Batch" /></td>
		</tr>
		</table>
	</td>
</tr> 
</table>
</form>
<?php } ?>

</center>
</body>
</html>