<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabFunctions.php');

$authentication['merchantID'] = $_POST['merchantID'];
$authentication['projectID'] = $_POST['projectID'];
$authentication['secretKey'] = $_POST['secretKey'];
$statusType = $_POST['statusType'];

$idArr = array(
	$statusType.'1',
  $statusType.'2',
  $statusType.'3',
  $statusType.'4',
  $statusType.'5'
);
	
// Check all parameters were received.
foreach ($idArr as $key) {
	if (!empty($_POST[$key])) {
  	$idList[$key] = $_POST[$key];
	}
}	
  	
$requestResult = call_user_func('statusRequest',$authentication, $statusType, $idList);

if($requestResult['success'] != 1){
	session_start();
	$_SESSION['error_result']= $requestResult;
	$redirect_url = "cabError.php";
	header("Location: $redirect_url");
	exit();		
}	
  
$requestResultValues = $requestResult['values'];
$requestTrackingID = $requestResultValues['requestTrackingID'];
$transactionList = $requestResultValues['transactionList']['transaction'];

if (!is_array($transactionList[0])) {
	$transactionList = array($transactionList);
}


$request = $requestResult['request'] ;
$response = $requestResult['response'];
  
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - StatusRequest</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
	<center>
	<table width="980" border="0" cellspacing="0" cellpadding="0">
		<tr>
	  	<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
	  	<td width="650" align="center" class="headlogo">ClickandBuy - StatusRequest</td>
	  	<td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
		</tr>
	</table>	
		
	<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
	<tr>
	  	<td colspan="2" class="head1">PayRequest StatusRequest</td>
		</tr>	    	
		<tr>
		<td width="50">&nbsp;</td>
		<td>
			<table width="680" border="0" cellspacing="0" cellpadding="0">
	    <tr>
	    	<td colspan="2" class="result_suc">Your ClickandBuy SOAP Request was successful!</td>
	    </tr>		
	    <tr>
	    	<td width="200">Request Tracking ID:</td>
	    	<td><?php echo $requestTrackingID; ?></td>
	    </tr>		    
	    <?php 	    	
	    	foreach($transactionList as $key => $value) {
    			empty($value['externalID']) ? $externalID = '-' : $externalID = $value['externalID']; 
	    		if(is_array($value['errorDetails'])) {    				
    				echo '
    				<tr>
							<td>External ID:</td>
					    <td>'.$externalID.'</td>							    	
    				</tr>
    				<tr>
							<td>Transaction ID:</td>
					    <td>'.$value['transactionID'].'</td>							    	
    				</tr>
    				<tr>
							<td>Detail Code:</td>
							<td>'.$value['errorDetails']['detailCode'].'</td>							    	
						</tr>
    				<tr>
							<td>Description:</td>
					   	<td>'.$value['errorDetails']['description'].'</td>							    	
    				</tr>
    					';	    					
    			} else {
    				echo '
    				<tr>
							<td>External ID:</td>
					   	<td>'.$externalID.'</td>							    	
    				</tr>
    				<tr>
							<td>Transaction ID:</td>
					   	<td>'.$value['transactionID'].'</td>							    	
    				</tr>
    				<tr>
							<td>Transaction Status:</td>
					   	<td>'.$value['transactionStatus'].'</td>							    	
    				</tr>
    				<tr>
							<td>Transaction Type:</td>
					   	<td>'.$value['transactionType'].'</td>							    	
    				</tr>';
    				
    				if(!empty($value['createdRecurringPaymentAuthorization']['recurringPaymentAuthorizationID']))
    				echo '<tr>
							<td>AuthorizationID:</td>
					   	<td>'.$value['createdRecurringPaymentAuthorization']['recurringPaymentAuthorizationID'].'</td>							    	
    				</tr>
    				<tr>
							<td>Authorization Status:</td>
					   	<td>'.$value['createdRecurringPaymentAuthorization']['recurringPaymentAuthorizationStatus'].'</td>							    	
    				</tr>
    				';	    				
    			}
	    	} 
	    ?>    
 	    </table>&nbsp;
    </td>
    </tr>
   	<tr>
    	<td colspan="2" class="head1">SOAP Request &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
    </tr>
		<tr>
		<td width="50">&nbsp;</td>
		<td>
			<div id="divbox1" style="display:none">			
			<table width="680" border="0"" cellspacing="0" cellpadding="0">
	    <tr>
	    	<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$request.'</textarea>'; ?></td>
	    	<td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
	    </tr>   
	    </table>
	    </div>&nbsp;
    </td>
    </tr>    
  	<tr>
    	<td colspan="2" class="head1">SOAP Response &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
    </tr>
		<tr>
		<td width="50">&nbsp;</td>
		<td>
			<div id="divbox2" style="display:none">			
			<table width="680" border="0"" cellspacing="0" cellpadding="0">
	    <tr>
	    	<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$response.'</textarea>'; ?></td>
	    	<td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
	    </tr>   
	    </table>
	    </div>&nbsp;
    </td>
    </tr>    
    </table>	
	</center>
</body>
</html>