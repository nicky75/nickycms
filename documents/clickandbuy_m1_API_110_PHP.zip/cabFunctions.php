<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

function doSoapRequest($reqName,$reqParam,$inc=true,$client=null) {	
	if($inc) {
		include('cabConstants.php');	
		include(NUSOAP_FOLDER.'nusoap.php');			
	}

	$client = new nusoap_client(SOAP_ENDPOINT);	
	$client->soap_defencoding = "UTF-8";
	$success = false;
	
	$result = $client->call($reqName,$reqParam,SOAP_NAMESPACE,SOAP_ACTION,false,null,"rpc","literal");
	
	if ($client->fault) {
		$nusoapResult['error_type'] = 'fault';		
		$nusoapResult['faultcode'] = $client->faultcode;
		$nusoapResult['faultstring'] = $client->faultstring;		
		$nusoapResult['faultdetail'] = $client->faultdetail;						

	} elseif($client->getError()) {
		$nusoapResult['error_type'] = 'error';
		$nusoapResult['error'] = $client->getError();		
	} else {
		$success = true;
	}

	$nusoapResult['success'] = $success;
	$nusoapResult['values'] = $result;		
	$nusoapResult['req_name'] = $reqName;
	$nusoapResult['request'] = $client->request;
	$nusoapResult['response'] = $client->response;
	
	return $nusoapResult; 
}

function generateToken($projectID,$secretKey) {
	$timestamp = gmdate("YmdHis");	
	$hashStr = $projectID."::".$secretKey."::".$timestamp;
	$toBeHashed = strtoupper(sha1($hashStr));	
	$token = $timestamp.'::'.$toBeHashed; 	
	
	return $token;	
}

function removeEmptyTag($arr) {
  foreach ($arr as $key => $value) {
    if(is_array($arr[$key])) {
  		foreach ($arr[$key] as $key2 => $value2) {
		  	if (empty($arr[$key][$key2])) {    	
		      unset($arr[$key][$key2]);
		  	}   	  			
  		}    	
    }     
  	if (empty($arr[$key])) {    	
  		unset($arr[$key]);
  	}   	
  } 
	return $arr;
}

function createItemList($items) {
	// Fill itemListArr
	$itemListArr = array ();
  foreach ($items as $key => $value) {
		$item = 'item'.$key;
		if($value['itemType'] == $item.'Text') {
			array_push($itemListArr,new soapval('item',false,array('itemType' => 'TEXT','description' => $value['textItemDescription'])));					    	
		} elseif($value['itemType'] == $item.'Item') {
			array_push($itemListArr,
				new soapval('item',false,
						array('itemType' => 'ITEM',
							'description' => $value['itemDescription'],
							'quantity' => $value['itemQuantity'],
							new soapval('unitPrice',false,array('amount' => $value['itemUnitPriceAmount'],'currency' => $value['itemUnitPriceCurrency'])),
							new soapval('totalPrice',false,array('amount' => $value['itemTotalPriceAmount'],'currency' => $value['itemTotalPriceCurrency']))
						)
				)
			);				
		} elseif($value['itemType'] == $item.'Subtotal') {
			array_push($itemListArr,
				new soapval('item',false,
						array('itemType' => 'SUBTOTAL',
							'description' => $value['subtotalItemDescription'],
							new soapval('totalPrice',false,array('amount' => $value['subtotalItemTotalPriceAmount'],'currency' => $value['subtotalItemTotalPriceCurrency']))
						)
				)
			);				
		} elseif($value['itemType'] == $item.'Vat') {
			array_push($itemListArr,
				new soapval('item',false,
						array('itemType' => 'VAT',
							'description' => $value['vatItemDescription'],
							new soapval('totalPrice',false,array('amount' => $value['vatItemTotalPriceAmount'],'currency' => $value['vatItemTotalPriceCurrency']))
						)
				)
			);				
		} elseif($value['itemType'] == $item.'Total') {
			array_push($itemListArr,
				new soapval('item',false,
						array('itemType' => 'TOTAL',
							'description' => $value['totalItemDescription'],
							new soapval('totalPrice',false,array('amount' => $value['totalItemTotalPriceAmount'],'currency' => $value['totalItemTotalPriceCurrency']))
						)
				)
			);				
		}
  }	
  return $itemListArr;	
}

function payRequest($authentication,$details,$shippingType,$shippingAddress,$billingType,$billingAddress,$items,$createRecurring) {			
	
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$amountArr = array(
		'amount' => $details['amount'],
		'currency' => $details['currency']
	);	

	$shippingAddressArr = array(
		$shippingType => $shippingAddress
	);	
	
	$billingAddressArr = array(
		$billingType => $billingAddress
	);	
			
	$itemListArr = array();
	if(!empty($items)) {		
		$itemListArr = call_user_func('createItemList',$items);		
	}

	$orderDetailsArr = array(
		'text' => $details['orderDescription'],
		'itemList' => $itemListArr
	);	

	$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
	
	$detailsArr = array(
		'amount' => $amountArr,
		'basketRisk' => $details['basketRisk'],
		'clientRisk' => $details['clientRisk'],
		'authExpiration' => $details['authExpiration'],
		'confirmExpiration' => $details['confirmExpiration'],
		'successExpiration' => $details['successExpiration'],
		'successURL' => $details['successURL'],
		'failureURL' => $details['failureURL'],
		'consumerIPAddress' => $details['consumerIPAddress'],
		'externalID' => $details['externalID'],
		'consumerLanguage' => $details['consumerLanguage'],
		'consumerCountry' => $details['consumerCountry'],	
		'orderDetails' => $orderDetailsArr,	
		'shipping' => $shippingAddressArr,	
		'billing' => $billingAddressArr,	
		'createRecurring' => $createRecurring		
	);	
			
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','payRequest_Request',$reqParam,false,$client);
	return $nusoapResult;	
}

function payRequestRecurring($authentication,$details,$shippingType,$shippingAddress,$billingType,$billingAddress,$items) {				
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);
	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$amountArr = array(
		'amount' => $details['amount'],
		'currency' => $details['currency']
	);	
	
	$shippingAddressArr = array(
		$shippingType => $shippingAddress
	);	
	
	$billingAddressArr = array(
		$billingType => $billingAddress
	);
	
	$itemListArr = array();
	if(!empty($items)) {		
		$itemListArr = call_user_func('createItemList',$items);		
	}
		
	$orderDetailsArr = array(
		'text' => $details['orderDescription'],
		'itemList' => $itemListArr
	);	

	$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
		
	$detailsArr = array(
		'amount' => $amountArr,
		'recurringPaymentAuthorizationID' => $details['recurringAuthorizationID'],	
		'basketRisk' => $details['basketRisk'],
		'clientRisk' => $details['clientRisk'],
		'externalID' => $details['externalID'],
		'authExpiration' => $details['authExpiration'],	
		'successExpiration' => $details['successExpiration'],
		'orderDetails' => $orderDetailsArr,	
		'shipping' => $shippingAddressArr,	
		'billing' => $billingAddressArr,		
	);	
		
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','payRequestRecurring_Request',$reqParam,false,$client);
	return $nusoapResult;		
}

function refundRequest($authentication,$details,$items) {	
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		

	$amountArr = array(
		'amount' => $details['amount'],
		'currency' => $details['currency']
	);			
	
	$itemListArr = array();
	if(!empty($items)) {		
		$itemListArr = call_user_func('createItemList',$items);		
	}
	
	$orderDetailsArr = array(
		'itemList' => $itemListArr
	);	

	$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
	  	
	$detailsArr = array(
		'amount' => $amountArr,
		'transactionID' => $details['transactionID'],
		'externalID' => $details['externalID'],
		'orderDetails' => $orderDetailsArr
	);
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 				
	$nusoapResult = call_user_func('doSoapRequest','refundRequest_Request',$reqParam,false,$client);
	return $nusoapResult;		
}

function cancelRequest($authentication,$transactionID) {		
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		

	$detailsArr = array(
		'transactionID' => $transactionID
	);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);		
		
	$nusoapResult = call_user_func('doSoapRequest','cancelRequest_Request',$reqParam);	
	return $nusoapResult;		
}

function cancelRequest110($authentication,$details) {		
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		

	$detailsArr = array(
		'cancelMode' => $details['cancelMode'],
		'cancelIdentifier' => $details['cancelIdentifier']
	);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);		
		
	$nusoapResult = call_user_func('doSoapRequest','cancelRequest_Request',$reqParam);	
	return $nusoapResult;		
}

function creditRequest($authentication,$details,$items) {
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);			
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		

	$amountArr = array(
		'amount' => $details['amount'],
		'currency' => $details['currency']
	);			
	
	$itemListArr = array();
	if(!empty($items)) {		
		$itemListArr = call_user_func('createItemList',$items);		
	}
	
	$orderDetailsArr = array(
		'itemList' => $itemListArr
	);	

	$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
	  	
	$detailsArr = array(
		'amount' => $amountArr,
		'emailAddress' => $details['emailAddress'],
		'externalID' => $details['externalID'],
		'orderDetails' => $orderDetailsArr	
	);
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 				
	$nusoapResult = call_user_func('doSoapRequest','creditRequest_Request',$reqParam,false,$client);	
	return $nusoapResult;		
}

function creditRequest110($authentication,$details,$items) {
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);			
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		

	$amountArr = array(
		'amount' => $details['amount'],
		'currency' => $details['currency']
	);
	
	// Selection of Credit Recipient (by Email or by CRN)
	if (isset($details['EmailAddress'])) {
		$recipientArr = array(
			'emailAddress' => $details['EmailAddress']
		);
	} else if (isset($details['CRN'])) {
		$recipientArr = array(
			'crn' => $details['CRN']
		);
	}
	
	$itemListArr = array();
	if(!empty($items)) {		
		$itemListArr = call_user_func('createItemList',$items);		
	}
	
	$orderDetailsArr = array(
		'itemList' => $itemListArr
	);	

	$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
	  	
	$detailsArr = array(
		'amount' => $amountArr,
		'recipient' => $recipientArr,
		'externalID' => $details['externalID'],
		'orderDetails' => $orderDetailsArr	
	);
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 				
	$nusoapResult = call_user_func('doSoapRequest','creditRequest_Request',$reqParam,false,$client);	
	return $nusoapResult;		
}

function statusRequest($authentication,$statusType,$ids) {	
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);			
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);	
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		

	$idListArr = array();
	if(!empty($ids)) {		
		// Fill idListArr
	  foreach ($ids as $key => $value) {
				array_push($idListArr,new soapval($statusType,false,$value));					    	
		}
	}		
	
	$detailsArr = array(
		$statusType.'List' => $idListArr
	);
		
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 		
	$nusoapResult = call_user_func('doSoapRequest','statusRequest_Request',$reqParam,false,$client);
	return $nusoapResult;		
}

function getAccountingDocuments110($authentication,$details) {
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');
	
	$client = new nusoap_client(SOAP_ENDPOINT);			
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);
		
	$detailsArr = array();
	$detailsArr['date']['after'] = $details['date']['after'];
	$detailsArr['date']['before'] = $details['date']['before'];
	$detailsArr['documentType'] = $details['documentType'];
	$detailsArr['fileType'] = $details['fileType'];
	$detailsArr['fileName'] = $details['fileName'];
	$detailsArr['documentNumber']['from'] = $details['documentNumber']['from'];
	$detailsArr['documentNumber']['until'] = $details['documentNumber']['until'];
	$detailsArr['paging']['skip'] = $details['paging']['skip'];
	$detailsArr['paging']['maxResults'] = $details['paging']['maxResults'];
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 				
	$nusoapResult = call_user_func('doSoapRequest','getAccountingDocuments_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function createBatch($authentication,$externalBatchID) {	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);	
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		

	$detailsArr = array(
		'externalBatchID' => $externalBatchID
	);
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);		
		
 	$nusoapResult = call_user_func('doSoapRequest','createBatch_Request',$reqParam);	
	return $nusoapResult;	
}

function addBatchPayRequest($authentication,$batchID,$itemList) {			
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);
	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$pos = 0;
	$batchItems = array();
	foreach($itemList as $key => $itemArr) {
		$amountArr = array(
			'amount' => $itemArr['amount'],
			'currency' => $itemArr['currency']
		);	
		
		$shippingAddressArr = array(
			$itemArr['shippingType'] => $itemArr['shippingAddress']
		);	
		
		$billingAddressArr = array(
			$itemArr['billingType'] => $itemArr['billingAddress']
		);
				
		$amountLimitArr = array(
			'amount' => $itemArr['recurring']['amountLimit']['amount'],
			'currency' => $itemArr['recurring']['amountLimit']['currency']
		);	
		
		$amountLimitArr = call_user_func('removeEmptyTag',$amountLimitArr);
			
		$createRecurringArr = array(
			'description' => $itemArr['recurring']['description'],
			'numberLimit' => $itemArr['recurring']['numberLimit'],
			'amountLimit' => $amountLimitArr,
			'expireDate' => $itemArr['recurring']['expireDate'],		
			'revokableByConsumer' => $itemArr['recurring']['revokableByConsumer']
		);	
	
		$createRecurringArr = call_user_func('removeEmptyTag',$createRecurringArr);
		
		$items = $itemArr['itemDetailList'];	
		$itemListArr = array();
		if(!empty($items)) {		
			$itemListArr = call_user_func('createItemList',$items);		
		}
	
		$orderDetailsArr = array(
			'text' => $itemArr['orderDescription'],
			'itemList' => $itemListArr
		);	
	
		$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
		
		$payRequestArr = array(
			'amount' => $amountArr,
			'basketRisk' => $itemArr['basketRisk'],
			'clientRisk' => $itemArr['clientRisk'],
			'authExpiration' => $itemArr['authExpiration'],
			'confirmExpiration' => $itemArr['confirmExpiration'],
			'successExpiration' => $itemArr['successExpiration'],
			'successURL' => $itemArr['successURL'],
			'failureURL' => $itemArr['failureURL'],
			'consumerIPAddress' => $itemArr['consumerIPAddress'],
			'externalID' => $itemArr['externalID'],
			'consumerLanguage' => $itemArr['consumerLanguage'],
			'consumerCountry' => $itemArr['consumerCountry'],	
			'orderDetails' => $orderDetailsArr,	
			'shipping' => $shippingAddressArr,	
			'billing' => $billingAddressArr,	
			'createRecurring' => $createRecurringArr	
		);	
		
		$payRequestArr = call_user_func('removeEmptyTag',$payRequestArr);
		
		$batchItemDetail = array(new soapval('payRequestDetails',false,$payRequestArr));		
		array_push($batchItems,new soapval('batchItemDetails',false,array('externalID' => $itemArr['batchItemExternalID'],'details' => $batchItemDetail)));
	}

	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
	$detailsArr = array(
		'batchID' => $batchID,
 		'batchItemDetailsList' => $batchItems 		
	);
		
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','addBatchItem_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function addBatchRecurring($authentication,$batchID,$itemList) {			
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);
	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$pos = 0;
	$batchItems = array();
	foreach($itemList as $key => $itemArr) {
		$amountArr = array(
			'amount' => $itemArr['amount'],
			'currency' => $itemArr['currency']
		);	
				
		$shippingAddressArr = array(
			$itemArr['shippingType'] => $itemArr['shippingAddress']
		);	
		
		$billingAddressArr = array(
			$itemArr['billingType'] => $itemArr['billingAddress']
		);
						
		$items = $itemArr['itemDetailList'];	
		$itemListArr = array();
		if(!empty($items)) {		
			$itemListArr = call_user_func('createItemList',$items);		
		}
	
		$orderDetailsArr = array(
			'text' => $itemArr['orderDescription'],
			'itemList' => $itemListArr
		);	
	
		$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
				
		$payRequestRecurringArr = array(
			'amount' => $amountArr,
			'recurringPaymentAuthorizationID' => $itemArr['recurringPaymentAuthorizationID'],
			'basketRisk' => $itemArr['basketRisk'],
			'clientRisk' => $itemArr['clientRisk'],
			'externalID' => $itemArr['externalID'],
			'successExpiration' => $itemArr['successExpiration'],		
			'orderDetails' => $orderDetailsArr,	
			'shipping' => $shippingAddressArr,	
			'billing' => $billingAddressArr
		);	
		
		$payRequestRecurringArr = call_user_func('removeEmptyTag',$payRequestRecurringArr);
		
		$batchItemDetail = array(new soapval('payRequestRecurringDetails',false,$payRequestRecurringArr));		
		array_push($batchItems,new soapval('batchItemDetails',false,array('externalID' => $itemArr['batchItemExternalID'],'details' => $batchItemDetail)));
	}
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		
				
	$detailsArr = array(
		'batchID' => $batchID,
 		'batchItemDetailsList' => $batchItems 		
		);
		
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','addBatchItem_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function addBatchCredit($authentication,$batchID,$itemList) {			
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);
	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);

	$pos = 0;
	$batchItems = array();
	foreach($itemList as $key => $itemArr) {
		$amountArr = array(
			'amount' => $itemArr['amount'],
			'currency' => $itemArr['currency']
		);	
			
		$items = $itemArr['itemDetailList'];	
		$itemListArr = array();
		if(!empty($items)) {		
			$itemListArr = call_user_func('createItemList',$items);		
		}
	
		$orderDetailsArr = array(
			'text' => $itemArr['orderDescription'],
			'itemList' => $itemListArr
		);	
	
		$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
		
		if ($_SESSION["apiVersion"] == "1.0.0") {
			$requestArr = array(
				'amount' => $amountArr,
				'emailAddress' => $itemArr['emailAddress'],
				'consumerLanguage' => $itemArr['consumerLanguage'],
				'externalID' => $itemArr['externalID'],
			'orderDetails' => $orderDetailsArr
			);
		} else if ($_SESSION["apiVersion"] == "1.1.0") {
			$recipientArr = array();
			if (isset($itemArr['recipient']['emailAddress'])) $recipientArr['emailAddress'] = $itemArr['recipient']['emailAddress'];
			else if (isset($itemArr['recipient']['crn'])) $recipientArr['crn'] = $itemArr['recipient']['crn'];
			$requestArr = array(
				'amount' => $amountArr,
				'recipient' => $recipientArr,
				'consumerLanguage' => $itemArr['consumerLanguage'],
				'externalID' => $itemArr['externalID'],
			'orderDetails' => $orderDetailsArr
			);
		}
		
		$creditArr = call_user_func('removeEmptyTag',$requestArr);
		
		$batchItemDetail = array(new soapval('creditRequestDetails',false,$creditArr));		
		array_push($batchItems,new soapval('batchItemDetails',false,array('externalID' => $itemArr['batchItemExternalID'],'details' => $batchItemDetail)));		
	}
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
	$detailsArr = array(
		'batchID' => $batchID,
 		'batchItemDetailsList' => $batchItems 		
	);
		
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','addBatchItem_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function addBatchRefund($authentication,$batchID,$itemList) {			
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$pos = 0;
	$batchItems = array();
	foreach($itemList as $key => $itemArr) {
		$amountArr = array(
			'amount' => $itemArr['amount'],
			'currency' => $itemArr['currency']
		);	
			
		$items = $itemArr['itemDetailList'];	
		$itemListArr = array();
		if(!empty($items)) {		
			$itemListArr = call_user_func('createItemList',$items);		
		}
	
		$orderDetailsArr = array(
			'text' => $itemArr['orderDescription'],
			'itemList' => $itemListArr
		);	
	
		$orderDetailsArr = call_user_func('removeEmptyTag',$orderDetailsArr);
										
		$requestArr = array(
			'amount' => $amountArr,
			'transactionID' => $itemArr['transactionID'],
			'orderDetails' => $orderDetailsArr,
			'externalID' => $itemArr['externalID']
		);	
		
		$refundArr = call_user_func('removeEmptyTag',$requestArr);

		$batchItemDetail = array(new soapval('refundRequestDetails',false,$refundArr));		
		array_push($batchItems,new soapval('batchItemDetails',false,array('externalID' => $itemArr['batchItemExternalID'],'details' => $batchItemDetail)));		
	}
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
	$detailsArr = array(
		'batchID' => $batchID,
 		'batchItemDetailsList' => $batchItems 		
	);
		
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','addBatchItem_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function addBatchCancel($authentication,$batchID,$itemList) {		
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);		
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$pos = 0;
	$batchItems = array();
	foreach($itemList as $key => $itemArr) {							
		if ($_SESSION["apiVersion"] == "1.0.0") {
			$requestArr = array(
				'transactionID' => $itemArr['transactionID']
			);
		} else if ($_SESSION["apiVersion"] == "1.1.0") {
			$cancelIdentArr = array();
			if (isset($itemArr['cancelIdentifier']['transactionID'])) $cancelIdentArr['transactionID'] = $itemArr['cancelIdentifier']['transactionID'];
			if (isset($itemArr['cancelIdentifier']['rpaID'])) $cancelIdentArr['recurringPaymentAuthorizationID'] = $itemArr['cancelIdentifier']['rpaID'];
			$requestArr = array(
				'cancelMode' => $itemArr['cancelMode'],
				'cancelIdentifier' => $cancelIdentArr
			);
		}
		
		$cancelArr = call_user_func('removeEmptyTag',$requestArr);

		$batchItemDetail = array(new soapval('cancelRequestDetails',false,$cancelArr));		
		array_push($batchItems,new soapval('batchItemDetails',false,array('externalID' => $itemArr['batchItemExternalID'],'details' => $batchItemDetail)));		
		
	}
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		
				
	$detailsArr = array(
		'batchID' => $batchID,
 		'batchItemDetailsList' => $batchItems 		
	);
		
 	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr
 	);
	 		 	
	$nusoapResult = call_user_func('doSoapRequest','addBatchItem_Request',$reqParam,false,$client);	
	return $nusoapResult;	
}

function executeBatch($authentication,$batchID) {	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		

	$detailsArr = array(
		'batchID' => $batchID
	);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);		
		
	$nusoapResult = call_user_func('doSoapRequest','executeBatch_Request',$reqParam);	
	return $nusoapResult;	
}

function getBatchStatus($authentication,$batchID,$externalBatchID,$batchItemsArr) {		
	include('cabConstants.php');	
	include(NUSOAP_FOLDER.'nusoap.php');	
	
	$client = new nusoap_client(SOAP_ENDPOINT);			
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);

	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
		);		

	if(!empty($batchItemsArr)) {		
		// Fill itemListArr
		$batchItemIDListArr = array();
	  foreach ($batchItemsArr as $key => $value) {
				array_push($batchItemIDListArr,new soapval('batchItemID',false,$value));					    	
	  }		
	}
	
  $detailsArr = array(
		'batchID' => $batchID,
		'externalBatchID' => $externalBatchID,
		'batchItemIDList' => $batchItemIDListArr
	);
	
	$detailsArr = call_user_func('removeEmptyTag',$detailsArr);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);	
 		
	$nusoapResult = call_user_func('doSoapRequest','getBatchStatus_Request',$reqParam,false,$client);
	return $nusoapResult;
}

function cancelBatch($authentication,$batchID) {	
	$token = call_user_func('generateToken',$authentication['projectID'],$authentication['secretKey']);
	
	$authenticationArr = array(
		'merchantID' => $authentication['merchantID'],
		'projectID' => $authentication['projectID'],
		'token' => $token						
	);		

	$detailsArr = array(
		'batchID' => $batchID
	);
	
	$reqParam = array (
		'authentication' => $authenticationArr,
		'details' => $detailsArr 		
 	);		
		
	$nusoapResult = call_user_func('doSoapRequest','cancelBatch_Request',$reqParam);	
	return $nusoapResult;			
}

function logMmsEvent($xml) {
		$handle = fopen( 'mms.log', 'a+' );
		fwrite( $handle, "------------ new entry, received @ ". date( 'Y-m-d H:i:s' ) ." ------------------- \n" );
		fwrite( $handle, print_r( $xml, true ) . "\n" );
		fclose( $handle );
}

function sendMail($sendEmailTo,$sendEmailFrom,$text) {
	$subject = 'ClickandBuy MMS Event '.date('Y-m-d H:i:s');	
	$body = '
		<html>
			<head>
			  <title>MMS Event</title>
			</head>
			<body>
				------------ new entry, received @ '.date('Y-m-d H:i:s').' -------------------
				<p>'.htmlspecialchars($text,ENT_QUOTES).'</p>
			</body>
		</html>
	';
	
	// Set header
	$header  = 'MIME-Version: 1.0' . "\r\n";
	$header .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	$header .= 'To: <'.$sendEmailTo.'>' . "\r\n";
	$header .= 'From: <'.$sendEmailFrom.'>' . "\r\n";
	
	// Send mail
	mail($sendEmailTo, $subject, $body, $header);
}

function parseXML($xml) {
	include('lib/xml.php');		

	// Un-quotes a quoted string
	$data = stripslashes($xml);
		
	// Set Array 
	$xml = XML_unserialize($data);		
	
	return $xml;
}

function payEventList($payEventList) {
	if (!is_array($payEventList[0])) {
		$payEventList = array($payEventList);
	}

	foreach($payEventList as $key => $value) {
		$merchantID = $value['merchantID'];
		$projectID = $value['projectID'];
		$eventID = $value['eventID'];
		$creationDateTime = $value['creationDateTime'];
		$transactionID = $value['transactionID'];
		$externalID = $value['externalID'];
		$crn = $value['crn'];
		$transactionAmount = $value['transactionAmount']['amount'];
		$transactionCurrency = $value['transactionAmount']['currency'];
		$merchantAmount = $value['merchantAmount']['amount'];
		$merchantCurrency = $value['merchantAmount']['currency'];
		$oldState = $value['oldState'];
		$newState = $value['newState'];

		/*
		 * Write the data into the database!
		 */		
	}
}

function refundEventList($refundEventList) {
	if (!is_array($refundEventList[0])) {
		$refundEventList = array($refundEventList);
	}

	foreach($refundEventList as $key => $value) {
		$merchantID = $value['merchantID'];
		$projectID = $value['projectID'];
		$eventID = $value['eventID'];
		$creationDateTime = $value['creationDateTime'];
		$refundTransactionID = $value['refundTransactionID'];
		$associatedTransactionID = $value['associatedTransactionID'];
		if (isset($value['externalID'])) $externalID = $value['externalID'];
		$crn = $value['crn'];
		$transactionAmount = $value['transactionAmount']['amount'];
		$transactionCurrency = $value['transactionAmount']['currency'];
		$merchantAmount = $value['merchantAmount']['amount'];
		$merchantCurrency = $value['merchantAmount']['currency'];
		$oldState = $value['oldState'];
		$newState = $value['newState'];

		/*
		 * Write the data into the database!
		 */		
	}
}

function creditEventList($creditEventList) {
	if (!is_array($creditEventList[0])) {
		$creditEventList = array($creditEventList);
	}

	foreach($creditEventList as $key => $value) {
		$merchantID = $value['merchantID'];
		$projectID = $value['projectID'];
		$eventID = $value['eventID'];
		$creationDateTime = $value['creationDateTime'];
		$transactionID = $value['transactionID'];
		if (isset($value['recipient'])) $recipient = $value['recipient'];
		if (isset($value['email'])) $email = $value['email'];
		if (isset($value['externalID'])) $externalID = $value['externalID'];
		$crn = $value['crn'];
		$transactionAmount = $value['transactionAmount']['amount'];
		$transactionCurrency = $value['transactionAmount']['currency'];
		$merchantAmount = $value['merchantAmount']['amount'];
		$merchantCurrency = $value['merchantAmount']['currency'];
		$oldState = $value['oldState'];
		$newState = $value['newState'];

		/*
		 * Write the data into the database!
		 */		
	}
}

function recurringPaymentAuthorizationEventList($recurringEventList) {
	if (!is_array($recurringEventList[0])) {
		$recurringEventList = array($recurringEventList);
	}

	foreach($recurringEventList as $key => $value) {
		$merchantID = $value['merchantID'];
		$projectID = $value['projectID'];
		$eventID = $value['eventID'];
		$creationDateTime = $value['creationDateTime'];
		$transactionID = $value['transactionID'];
		if (isset($value['recurringPaymentAuthorizationID'])) $recurringPaymentAuthorizationID = $value['recurringPaymentAuthorizationID'];
		$externalID = $value['externalID'];
		$crn = $value['crn'];
		$amount = $value['amount']['amount'];
		$currency = $value['amount']['currency'];
		$oldState = $value['oldState'];
		$newState = $value['newState'];
		$remainingAmount = $value['remainingAmount']['amount'];
		$remainingCurrency = $value['remainingAmount']['currency'];
		$remainingRetries = $value['remainingRetries'];
		$validUntil = $value['validUntil'];
		
		/*
		 * Write the data into the database!
		 */		
	}
}

function batchEventList($batchEventList) {
	if (!is_array($batchEventList[0])) {
		$batchEventList = array($batchEventList);
	}

	foreach($batchEventList as $key => $value) {
		$merchantID = $value['merchantID'];
		$projectID = $value['projectID'];
		$eventID = $value['eventID'];
		$creationDateTime = $value['creationDateTime'];
		$batchID = $value['batchID'];
		$externalBatchID = $value['externalBatchID'];
		$itemCount = $value['itemCount'];
		if (isset($value['oldState'])) $oldState = $value['oldState'];
		$newState = $value['newState'];

		if (!is_array($value['batchItemlist']['batchItem'][0])) {
			$value['batchItemlist']['batchItem'] = array($value['batchItemlist']['batchItem']);
		}
		
		foreach($value['batchItemlist']['batchItem'] as $itemKey => $itemValue) {
			$batchItemID = $itemValue['batchItemID'];
			$externalID = $itemValue['externalID'];
			$batchItemStatus = $itemValue['batchItemStatus'];
			$resultTransactionID = $itemValue['resultTransactionID'];
			$errorCode = $itemValue['errorDetails']['code'];
			$errorDetailCode  = $itemValue['errorDetails']['detailCode'];
			$errorDescription = $itemValue['errorDetails']['description'];
			$errorRetry  = $itemValue['errorDetails']['retry'];
			
			/*
			 * Write the data into the database!
			 */		
		}		
	}
}	
	
function checkSignature($xml,$sharedKey) {	
	// find signature
	$signatureTag = "<signature>";
	$signatureTagStart = strpos($xml, $signatureTag);
	$signatureTagLength = strlen($signatureTag);

	$signatureStart = $signatureTagStart + $signatureTagLength;
	$signatureLength = 40;
	$signature = substr($xml,$signatureStart,$signatureLength);

	//signature from xml
	$xmlSignature = "<signature>".$signature."</signature>";	
	$emptySignature = "<signature />";
	$xmlWithoutSignature = str_replace($xmlSignature, $emptySignature, $xml);

	//Hash 
	$textToHash = $sharedKey.$xmlWithoutSignature;
	$hash = sha1 ($textToHash);

	($signature == $hash) ?  $result = true : $result = false;
	return $result;
}	


?>