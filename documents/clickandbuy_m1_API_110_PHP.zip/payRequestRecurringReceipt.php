<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabFunctions.php');

$authentication = array();
$details = array();
$shippingAddress = array();
$billingAddress = array();
$items = array();

$authentication['merchantID'] = $_POST['merchantID'];
$authentication['projectID'] = $_POST['projectID'];
$authentication['secretKey'] = $_POST['secretKey'];

// Pay request recurring details  
$details['amount'] = $_POST['amount'];
$details['currency'] = $_POST['currency'];	
$details['recurringAuthorizationID'] = $_POST['recurringAuthorizationID'];
$details['basketRisk'] = $_POST['basketRisk'];
$details['clientRisk'] = $_POST['clientRisk'];
$details['externalID'] = $_POST['externalID'];
$details['successExpiration'] = $_POST['successExpiration'];
$details['orderDescription'] = $_POST['orderDescription'];		

// Shipping Type and shipping details	
$shippingType = ($_POST['shippingType'] == 'shippingConsumer')? 'consumer' : 'company';

if($shippingType == 'consumer') {
	$shippingAddress['salutation'] = $_POST['shippingConsumerSalutation'];
	$shippingAddress['title'] = $_POST['shippingConsumerTitle'];
	$shippingAddress['firstName'] = $_POST['shippingConsumerFirstName'];
	$shippingAddress['lastName'] = $_POST['shippingConsumerLastName'];
	$shippingAddress['maidenName'] = $_POST['shippingConsumerMaidenName'];
	$shippingAddress['gender'] = $_POST['shippingConsumerGender'];
	$shippingAddress['dateOfBirth'] = $_POST['shippingConsumerDateOfBirth'];
	$shippingAddress['language'] = $_POST['shippingConsumerLanguage'];		
	$shippingAddress['address']['street'] = $_POST['shippingConsumerStreet'];
	$shippingAddress['address']['houseNumber'] = $_POST['shippingConsumerHouseNumber'];
	$shippingAddress['address']['houseNumberSuffix'] = $_POST['shippingConsumerHouseNumberSuffix'];
	$shippingAddress['address']['zip'] = $_POST['shippingConsumerZIP'];
	$shippingAddress['address']['city'] = $_POST['shippingConsumerCity'];
	$shippingAddress['address']['country'] = $_POST['shippingConsumerCountry'];
	$shippingAddress['address']['state'] = $_POST['shippingConsumerState'];
	$shippingAddress['address']['addressSuffix'] = $_POST['shippingConsumerAddressSuffix'];
	
} else {
	$shippingAddress['name'] = $_POST['shippingCompanyName'];
	$shippingAddress['vatID'] = $_POST['shippingCompanyVat'];
	$shippingAddress['registry']['registryID'] = $_POST['shippingCompanyRegistryID'];
	$shippingAddress['registry']['zip'] = $_POST['shippingCompanyRegistryZIP'];
	$shippingAddress['registry']['city'] = $_POST['shippingCompanyRegistryCity'];			
	$shippingAddress['address']['street'] = $_POST['shippingCompanyStreet'];
	$shippingAddress['address']['houseNumber'] = $_POST['shippingCompanyHouseNumber'];
	$shippingAddress['address']['houseNumberSuffix'] = $_POST['shippingCompanyHouseNumberSuffix'];
	$shippingAddress['address']['zip'] = $_POST['shippingCompanyZIP'];
	$shippingAddress['address']['city'] = $_POST['shippingCompanyCity'];
	$shippingAddress['address']['country'] = $_POST['shippingCompanyCountry'];
	$shippingAddress['address']['state'] = $_POST['shippingCompanyState'];
	$shippingAddress['address']['addressSuffix'] = $_POST['shippingCompanyAddressSuffix'];
} 

$shippingAddress = call_user_func('removeEmptyTag',$shippingAddress);

// Billing Type and billing details		
$billingType = ($_POST['billingType'] == 'billingConsumer')? 'consumer' : 'company';

if($billingType == 'consumer') {
	$billingAddress['salutation'] = $_POST['billingConsumerSalutation'];
	$billingAddress['title'] = $_POST['billingConsumerTitle'];
	$billingAddress['firstName'] = $_POST['billingConsumerFirstName'];
	$billingAddress['lastName'] = $_POST['billingConsumerLastName'];
	$billingAddress['maidenName'] = $_POST['billingConsumerMaidenName'];
	$billingAddress['gender'] = $_POST['billingConsumerGender'];
	$billingAddress['dateOfBirth'] = $_POST['billingConsumerDateOfBirth'];
	$billingAddress['language'] = $_POST['billingConsumerLanguage'];		
	$billingAddress['address']['street'] = $_POST['billingConsumerStreet'];
	$billingAddress['address']['houseNumber'] = $_POST['billingConsumerHouseNumber'];
	$billingAddress['address']['houseNumberSuffix'] = $_POST['billingConsumerHouseNumberSuffix'];
	$billingAddress['address']['zip'] = $_POST['billingConsumerZIP'];
	$billingAddress['address']['city'] = $_POST['billingConsumerCity'];
	$billingAddress['address']['country'] = $_POST['billingConsumerCountry'];
	$billingAddress['address']['state'] = $_POST['billingConsumerState'];
	$billingAddress['address']['addressSuffix'] = $_POST['billingConsumerAddressSuffix'];
} else {
	$billingAddress['name'] = $_POST['billingCompanyName'];
	$billingAddress['vatID'] = $_POST['billingCompanyVat'];
	$billingAddress['registry']['registryID'] = $_POST['billingCompanyRegistryID'];
	$billingAddress['registry']['zip'] = $_POST['billingCompanyRegistryZIP'];
	$billingAddress['registry']['city'] = $_POST['billingCompanyRegistryCity'];			
	$billingAddress['address']['street'] = $_POST['billingCompanyStreet'];
	$billingAddress['address']['houseNumber'] = $_POST['billingCompanyHouseNumber'];
	$billingAddress['address']['houseNumberSuffix'] = $_POST['billingCompanyHouseNumberSuffix'];
	$billingAddress['address']['zip'] = $_POST['billingCompanyZIP'];
	$billingAddress['address']['city'] = $_POST['billingCompanyCity'];
	$billingAddress['address']['country'] = $_POST['billingCompanyCountry'];
	$billingAddress['address']['state'] = $_POST['billingCompanyState'];
	$billingAddress['address']['addressSuffix'] = $_POST['billingCompanyAddressSuffix'];
} 

$billingAddress = call_user_func('removeEmptyTag',$billingAddress);

// Prepare items from Order Details
for($i=1;$i<=3;$i++) {	
	$item = 'item'.$i;
	$itemType = $_POST[$item.'ItemType'];		
	$items[$i]['itemType'] = $itemType;	

	if($itemType == $item.'Text') {
		$items[$i]['textItemDescription'] = $_POST[$item.'TextItemDescription'];			
	} elseif($itemType == $item.'Item') {
		$items[$i]['itemDescription'] = $_POST[$item.'ItemDescription'];	
		$items[$i]['itemQuantity'] = $_POST[$item.'ItemQuantity'];	
		$items[$i]['itemUnitPriceAmount'] = $_POST[$item.'ItemUnitPriceAmount'];	
		$items[$i]['itemUnitPriceCurrency'] = $_POST[$item.'ItemUnitPriceCurrency'];	
		$items[$i]['itemTotalPriceAmount'] = $_POST[$item.'ItemTotalPriceAmount'];	
		$items[$i]['itemTotalPriceCurrency'] = $_POST[$item.'ItemTotalPriceCurrency'];				
	} elseif($itemType == $item.'Subtotal') {
		$items[$i]['subtotalItemDescription'] = $_POST[$item.'SubtotalItemDescription'];	
		$items[$i]['subtotalItemTotalPriceAmount'] = $_POST[$item.'SubtotalItemTotalPriceAmount'];	
		$items[$i]['subtotalItemTotalPriceCurrency'] = $_POST[$item.'SubtotalItemTotalPriceCurrency'];	
	} elseif($itemType == $item.'Vat') {
		$items[$i]['vatItemDescription'] = $_POST[$item.'VatItemDescription'];	
		$items[$i]['vatItemTotalPriceAmount'] = $_POST[$item.'VatItemTotalPriceAmount'];	
		$items[$i]['vatItemTotalPriceCurrency'] = $_POST[$item.'VatItemTotalPriceCurrency'];	
	} elseif($itemType == $item.'Total') {
		$items[$i]['totalItemDescription'] = $_POST[$item.'TotalItemDescription'];	
		$items[$i]['totalItemTotalPriceAmount'] = $_POST[$item.'TotalItemTotalPriceAmount'];	
		$items[$i]['totalItemTotalPriceCurrency'] = $_POST[$item.'TotalItemTotalPriceCurrency'];	
	}					
}

$items = call_user_func('removeEmptyTag',$items);
 		
$requestResult = call_user_func('payRequestRecurring',$authentication,$details,$shippingType,$shippingAddress,$billingType,$billingAddress,$items);

if(!$requestResult['success']){
	session_start();
	$_SESSION['error_result']= $requestResult;
	header("Location: cabError.php");
	exit();		
 }	
  
$requestResultValues = $requestResult['values'];
$requestTrackingID = $requestResultValues['requestTrackingID'];
$transactionID = $requestResultValues['transaction']['transactionID'];
$transactionStatus = $requestResultValues['transaction']['transactionStatus'];
$transactionType = $requestResultValues['transaction']['transactionType'];
$redirectURL = $requestResultValues['transaction']['redirectURL'];  

$request = $requestResult['request'] ;
$response = $requestResult['response'];
		 
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - PayRequest Recurring</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>

<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="650" align="center" class="headlogo">ClickandBuy - PayRequest Recurring</td>
  <td align="right" valign="top" class="headlogo"><a href="index.html">Home</a></td>
</tr>
</table>	
		
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">PayRequest Recurring Result</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td colspan="2" class="result_suc">Your ClickandBuy SOAP Request was successful!</td>
    </tr>		
    <tr>
    	<td width="200">Request Tracking ID:</td>
    	<td><?php echo $requestTrackingID; ?></td>
    </tr>		
    <tr>
    	<td>Transaction ID:</td>
    	<td><?php echo $transactionID; ?></td>
    </tr>		
    <tr>
    	<td>Transaction Status:</td>
    	<td><?php echo $transactionStatus; ?></td>
    </tr>		    
    <tr>
    	<td>Transaction Type:</td>
    	<td><?php echo $transactionType; ?></td>
    </tr>		    
		</table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">SOAP Request &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
			<tr>
		  	<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$request.'</textarea>'; ?></td>
		    <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
			</tr>   
		</table>
		</div>&nbsp;
	</td>
</tr>    
<tr>
	<td colspan="2" class="head1">SOAP Response &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox2" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$response.'</textarea>'; ?></td>
		  <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
		</tr>   
		</table>
		</div>&nbsp;
	</td>
</tr>    
</table>	

</center>
</body>
</html>