<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

include('cabConstants.php');	
include('cabFunctions.php');

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - RefundRequest</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>
	
<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="100%" align="center" class="headlogo">ClickandBuy - RefundRequest</td>
  <td align="right" valign="top" class="headlogo"><a href="index.php">Home</a></td>
</tr>
</table>	
	
 <form action="refundRequestReceipt.php" method="POST" >
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">Merchant Info</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
		<tr>
	  	<td width="200">Merchant ID:</td>
	    <td><input type="text" name="merchantID" value="<?php echo MERCHANT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
		</tr>		
	  <tr>
	  	<td>Project ID:</td>
	    <td><input type="text" name="projectID" value="<?php echo PROJECT_ID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
		</tr>		
	  <tr>
	  	<td>Secret Key:</td>
			<td><input type="text" name="secretKey" value="<?php echo SECRET_KEY; ?>" /></td>
		</tr>		    
		</table>&nbsp;		
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Refund Request Details  </td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
	  <tr>
    	<td width="200">Amount: </td>
    	<td>
				<input name="amount" type="text"  value="1.00" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"> (1.00)
			</td>
    </tr>	    	
	  <tr>
    	<td>Currency: </td>
    	<td>
				<select name="currency" size="1">
		      <option value="EUR">EUR</option>
		      <option value="GBP">GBP</option>
		      <option value="USD">USD</option>
		    </select>
			</td>
    </tr>	     
    <tr>
    	<td>Transaction ID: </td>
    	<td><input type="text" name="transactionID" value="" /></td>
    </tr>	    	
    <tr>
    	<td>ExternalID: </td>
    	<td><input type="text" name="externalID" value="" /></td>
    </tr>	 	    	
		</table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">Order Details &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0" cellspacing="0" cellpadding="0">
   <!-- Item 1 -->
    <tr>
	    <td width="200">Item 1: </td>
	    <td>
				<select name="item1ItemType" id="itemType" onChange="ShowAndHideOthersItem1(this.value)">
					<option value="">Select Item Type</option>
					<option value="item1Text">TEXT</option>
					<option value="item1Item">ITEM</option>
					<option value="item1Subtotal">SUBTOTAL</option>
					<option value="item1Vat">VAT</option>
					<option value="item1Total">TOTAL</option>
				</select>
	    </td>
	    <td width="40" align="right"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 1 - text -->
				<div id="item1Text" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - item -->
				<div id="item1Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item1ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item1ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item1ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - subtotal -->
				<div id="item1Subtotal" style="display:none">
				<table width="680" border="0 cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - vat -->
				<div id="item1Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 1 - total -->
				<div id="item1Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item1TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item1TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item1TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr>						
   	<!-- Item 2 -->
    <tr>
	    <td width="200">Item 2: </td>
	    <td colspan="2">
				<select name="item2ItemType" id="itemType" onChange="ShowAndHideOthersItem2(this.value)">
					<option value="">Select Item Type</option>
					<option value="item2Text">TEXT</option>
					<option value="item2Item">ITEM</option>
					<option value="item2Subtotal">SUBTOTAL</option>
					<option value="item2Vat">VAT</option>
					<option value="item2Total">TOTAL</option>
				</select>
	    </td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 2 - item -->
				<div id="item2Text" style="display:none">
				<table width="680" border="0"" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - item -->
				<div id="item2Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item2ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item2ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item2ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - subtotal -->
				<div id="item2Subtotal" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - vat -->
				<div id="item2Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 2 - total -->
				<div id="item2Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item2TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item2TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item2TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr>
   <!-- Item 3 -->
    <tr>
	    <td width="200">Item 3: </td>
	    <td colspan="2">
				<select name="item3ItemType" id="itemType" onChange="ShowAndHideOthersItem3(this.value)">
					<option value="">Select Item Type</option>
					<option value="item3Text">TEXT</option>
					<option value="item3Item">ITEM</option>
					<option value="item3Subtotal">SUBTOTAL</option>
					<option value="item3Vat">VAT</option>
					<option value="item3Total">TOTAL</option>
				</select>
	    </td>
    </tr>       
		<tr>
			<td colspan="3">
			  <!-- Item 3 - text -->
				<div id="item3Text" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3TextItemDescription" value="" /></td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - item -->
				<div id="item3Item" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3ItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Quantity</td>
			    <td class="clear"><input type="text" name="item3ItemQuantity" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Amount</td>
			    <td class="clear"><input name="item3ItemUnitPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Unit Price Currency</td>
			    <td class="clear">
						<select name="item3ItemUnitPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3ItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3ItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - subtotal -->
				<div id="item3Subtotal" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3SubtotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3SubtotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3SubtotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
			    </td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - vat -->
				<div id="item3Vat" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3VatItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3VatItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3VatItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			  <!-- Item 3 - total -->
				<div id="item3Total" style="display:none">
				<table width="680" border="0" cellspacing="0" cellpadding="0">
		    <tr>
			    <td width="200">Item Description</td>
			    <td class="clear"><input type="text" name="item3TotalItemDescription" value="" /></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Amount</td>
			    <td class="clear"><input name="item3TotalItemTotalPriceAmount" type="text"  value="" size="5" maxlength="12" onkeypress="return AllowNumericOnly(event);"></td>						
		    </tr>   
		    <tr>
			    <td>Item Total Price Currency</td>
			    <td class="clear">
						<select name="item3TotalItemTotalPriceCurrency" size="1">
							<option value="EUR">EUR</option>
							<option value="GBP">GBP</option>
							<option value="USD">USD</option>
						</select>
					</td>						
		    </tr>   
				</table>&nbsp;			
				</div>
			</td>	
		</tr> 
		</table>
	  </div>&nbsp;
	</td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
	    <td width="200">&nbsp;</td>
  	  <td><input type="submit" name="submit" value="Submit" /></td>
    </tr>
    </table>
	</td>
</tr>        
</table>
</form>

</center>
</body>
</html>