<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

session_start();

include('cabFunctions.php');

$authentication['merchantID'] = $_POST['merchantID'];
$authentication['projectID'] = $_POST['projectID'];
$authentication['secretKey'] = $_POST['secretKey'];

$batchID = $_POST['batchID'];		
$itemList = $_SESSION['recurringItemList'][$batchID];

$requestResult = call_user_func('addBatchRecurring',$authentication,$batchID,$itemList);

if($requestResult['success'] != 1){
	$_SESSION['error_result']= $requestResult;
	$redirect_url = "cabError.php";
	header("Location: $redirect_url");
	exit();		
}	
  
$requestResultValues = $requestResult['values'];
$requestTrackingID = $requestResultValues['requestTrackingID'];
$batchID = $requestResultValues['batch']['batchID'];
$externalBatchID = $requestResultValues['batch']['externalBatchID'];
$batchStatus = $requestResultValues['batch']['batchStatus'];
$batchItems = $requestResultValues['batchItemList']['batchItem'];

if (!is_array($batchItems[0])) {
	$batchItems = array($batchItems);
}

if(empty($externalBatchID)) {
	$externalBatchID = '-';
}

$request = $requestResult['request'] ;
$response = $requestResult['response'];

 
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - AddBatchItem PayRequest Recurring</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>
<center>
	
<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
  <td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
  <td width="650" align="center" class="headlogo">ClickandBuy - AddBatchItem PayRequest Recurring</td>
  <td align="right" valign="top" class="headlogo"><a href="index.html">Home</a></td>
</tr>
</table>	
		
<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">AddBatchItem PayRequest Recurring Result</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td colspan="2" class="result_suc">Your ClickandBuy SOAP Request was successful!</td>
    </tr>		
    <tr>
    	<td width="200">Request Tracking ID:</td>
    	<td><?php echo $requestTrackingID; ?></td>
    </tr>		
    <tr>
    	<td>Batch ID:</td>
    	<td><?php echo $batchID; ?></td>
    </tr>
    <tr>
    	<td>External Batch ID:</td>
    	<td><?php echo $externalBatchID; ?></td>
    </tr>
    <tr>
    	<td>Batch Status:</td>
    	<td><?php echo $batchStatus; ?></td>
    </tr>
    <?php foreach ($batchItems as $key => $value) { ?>		
    <tr>
    	<td>Batch Item ID:</td>
    	<td><?php echo $value['batchItemID']; ?></td>
    </tr>		    
    <tr>
    	<td>Batch Item Status:</td>
    	<td><?php echo $value['batchItemStatus']; ?></td>
    </tr>		
		<?php } ?>
    </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">SOAP Request &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$request.'</textarea>'; ?></td>
		  <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
		</tr>   
		</table>
		</div>&nbsp;
	</td>
</tr>    
<tr>
	<td colspan="2" class="head1">SOAP Response &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox2" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$response.'</textarea>'; ?></td>
		  <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
		</tr>   
		</table>
		</div>&nbsp;
	</td>
</tr>    
</table>	

</center>
</body>
</html>