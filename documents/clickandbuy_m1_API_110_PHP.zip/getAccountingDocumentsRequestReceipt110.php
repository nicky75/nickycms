<?php
	// Include Helper-Functions 
	include('cabFunctions.php');

	$authentication = array();
	$details = array();

	$authentication['merchantID'] = $_POST['merchantID'];
	$authentication['projectID'] = $_POST['projectID'];
	$authentication['secretKey'] = $_POST['secretKey'];

	// Build Details-Part of request
	$details['date']['after'] = $_POST['fromDate'];
	$details['date']['before'] = $_POST['toDate'];
	$details['documentType'] = $_POST['documentType'];
	$details['fileType'] = $_POST['fileType'];
	$details['fileName'] = $_POST['fileName'];
	$details['documentNumber']['from'] = $_POST['minDocNo'];
	$details['documentNumber']['until'] = $_POST['maxDocNo'];
	$details['paging']['skip'] = $_POST['skipResults'];
	$details['paging']['maxResults'] = $_POST['maxResults'];

	$requestResult = call_user_func('getAccountingDocuments110',$authentication,$details);

	// Error Handling
	if($requestResult['success'] != 1) {
		session_start();
		$_SESSION['error_result']= $requestResult;
		$redirect_url = "cabError.php?apiVersion=v1.1.0";
		header("Location: $redirect_url");
		exit();		
	}
  
	// Fetch results
	$requestResultValues = $requestResult['values'];
	$requestTrackingID = $requestResultValues['requestTrackingID'];
	$skip = $requestResultValues['documentList']['paging']['skip'];
	$maxResults = $requestResultValues['documentList']['paging']['maxResults'];
	$resultCount = $requestResultValues['documentList']['paging']['resultCount'];
	$totalResultCount = $requestResultValues['documentList']['paging']['totalResultCount'];

	$document = $requestResultValues['documentList']['document'];
	
	$xml = $requestResult['values']['documentList']['document'];
	
	// Fetch Request and Response XML
	$request = $requestResult['request'] ;
	$response = $requestResult['response'];
?>
<html>
	<!-- Begin HTML Head -->
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>ClickandBuy - GetAccountingDocuments (API v1.1.0)</title>
		<link href="include/style.css" rel="stylesheet" type="text/css" />
		<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
	</head>
	<!-- Begin HTML Body -->
	<body>
		<center>
			<table width="980" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
					<td width="650" align="center" class="headlogo">ClickandBuy - GetAccountingDocuments (API v1.1.0)</td>
					<td align="right" valign="top" class="headlogo">
						<a href="index.php">Home</a>
					</td>
				</tr>
			</table>	
			<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
				<tr>
					<td colspan="2" class="head1">GetAccountingDocumentsRequest Result</td>
				</tr>	    	
				<tr>
					<td width="50">&nbsp;</td>
					<td>
						<table width="680" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td colspan="2" class="result_suc">Your ClickandBuy SOAP Request was successful!</td>
							</tr>		
							<tr>
								<td width="200">Request Tracking ID:</td>
								<td><?php echo $requestTrackingID; ?></td>
							</tr>		
							<tr>
								<td width="200">Skip:</td>
								<td><?php echo $skip; ?></td>
							</tr>		
							<tr>
								<td width="200">Max. Results:</td>
								<td><?php echo $maxResults; ?></td>
							</tr>
							<tr>
								<td width="200">Result Count:</td>
								<td><?php echo $resultCount; ?></td>
							</tr>
							<tr>
								<td width="200">Total Result Count:</td>
								<td><?php echo $totalResultCount; ?></td>
							</tr>
						</table>
						&nbsp;
						&nbsp;
						<hr />
						<table width="680" border="0" cellspacing="0" cellpadding="0">
							<tr>
								<td width="200">Documents:</td>
								<td><?php 
										if (empty($xml)) {
											echo 'No Results received';
										} else {
											foreach ($xml AS $key => $value) {
												if (!is_array($value))
													echo '<tr><td width="200">'.$key.':</td><td width="200">'.$value.'</td></tr>';
												else {
													foreach ($value AS $subKey => $subValue) {
														if (($subKey == 'serviceAreaLink') || ($subKey == 'directLink')) {
															echo '<tr><td width="200"># '.$subKey.':</td><td><a href="'.$subValue.'">'.$subValue.'</a></td></tr>';
														} else {
															//echo 'Geht noch weiter';
															if (!is_array($subValue))
																echo '<tr><td width="200">'.$subKey.':</td><td>'.$subValue.'</td></tr>';
															else {
																foreach ($subValue AS $subSubKey => $subSubValue) {
																	if (($subSubKey == 'serviceAreaLink') || ($subSubKey == 'directLink')) 
																		echo '<tr><td width="200"># '.$subSubKey.':</td><td><a href="'.$subSubValue.'">'.$subSubValue.'</a></td></tr>';
																}
																echo '<tr><td width="200" height="20" /></tr>';
															}
														}
													}
												}
											}
										}
									?>
								</td>
							</tr>
						</table>&nbsp;
					</td>
				</tr>
				<tr>
					<td colspan="2" class="head1">SOAP Request &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
				</tr>
				<tr>
					<td width="50">&nbsp;</td>
					<td>
						<div id="divbox1" style="display:none">			
							<table width="680" border="0"" cellspacing="0" cellpadding="0">
								<tr>
									<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$request.'</textarea>'; ?></td>
									<td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
								</tr>   
							</table>
						</div>&nbsp;
					</td>
				</tr>    
				<tr>
					<td colspan="2" class="head1">SOAP Response &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
				</tr>
				<tr>
					<td width="50">&nbsp;</td>
					<td>
						<div id="divbox2" style="display:none">			
							<table width="680" border="0"" cellspacing="0" cellpadding="0">
								<tr>
									<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$response.'</textarea>'; ?></td>
									<td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
								</tr>   
							</table>
						</div>&nbsp;
					</td>
				</tr>    
			</table>
		</center>
	</body>
</html>