<?php 
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

session_start();
include('cabFunctions.php');

$itemArr = array();
$items = array();
$shippingAddress = array();
$billingAddress = array();

$_SESSION['merchantID'] = $_POST['merchantID'];
$_SESSION['projectID'] = $_POST['projectID'];
$_SESSION['secretKey'] = $_POST['secretKey'];

$action = empty($_POST['action']) ? $_GET['action'] : $_POST['action']; 
$batchID = empty($_POST['batchID']) ? $_GET['batchID'] : $_POST['batchID'];
$itemNo = empty($_POST['itemNo']) ? $_GET['itemNo'] : $_POST['itemNo'];

$redirectUrl = 'payRequestBatch.php?batchID='.$batchID;

if($action == 'deleteItem') {
	unset($_SESSION['payRequestItemList'][$batchID][$itemNo]);
} elseif($action == 'addItem') {	
	$count = count($_SESSION['payRequestItemList'][$batchID]);
	$pos = $count+1;		
	
	$itemArr['pos'] = $pos;
	$itemArr['batchItemExternalID'] = $_POST['batchItemExternalID'];
	$itemArr['amount'] = $_POST['amount'];
	$itemArr['currency'] = $_POST['currency'];	
	$itemArr['basketRisk'] = $_POST['basketRisk'];
	$itemArr['clientRisk'] = $_POST['clientRisk'];
	$itemArr['authExpiration'] = $_POST['authExpiration'];
	$itemArr['confirmExpiration'] = $_POST['confirmExpiration'];
	$itemArr['successExpiration'] = $_POST['successExpiration'];
	$itemArr['successURL'] = $_POST['successURL'];
	$itemArr['failureURL'] = $_POST['failureURL'];
	$itemArr['consumerIPAddress'] = $_POST['consumerIPAddress'];
	$itemArr['externalID'] = $_POST['externalID'];
	$itemArr['consumerLanguage'] = $_POST['consumerLanguage'];
	$itemArr['consumerCountry'] = $_POST['consumerCountry'];		
	$itemArr['orderDescription'] = $_POST['orderDescription'];		
	
	// Shipping Type and shipping details	
	$shippingType = ($_POST['shippingType'] == 'shippingConsumer')? 'consumer' : 'company';
	$itemArr['shippingType'] = $shippingType;
	
	if($shippingType == 'consumer') {
		$shippingAddress['salutation'] = $_POST['shippingConsumerSalutation'];
		$shippingAddress['title'] = $_POST['shippingConsumerTitle'];
		$shippingAddress['firstName'] = $_POST['shippingConsumerFirstName'];
		$shippingAddress['lastName'] = $_POST['shippingConsumerLastName'];
		$shippingAddress['maidenName'] = $_POST['shippingConsumerMaidenName'];
		$shippingAddress['gender'] = $_POST['shippingConsumerGender'];
		$shippingAddress['dateOfBirth'] = $_POST['shippingConsumerDateOfBirth'];
		$shippingAddress['language'] = $_POST['shippingConsumerLanguage'];		
		$shippingAddress['address']['street'] = $_POST['shippingConsumerStreet'];
		$shippingAddress['address']['houseNumber'] = $_POST['shippingConsumerHouseNumber'];
		$shippingAddress['address']['houseNumberSuffix'] = $_POST['shippingConsumerHouseNumberSuffix'];
		$shippingAddress['address']['zip'] = $_POST['shippingConsumerZIP'];
		$shippingAddress['address']['city'] = $_POST['shippingConsumerCity'];
		$shippingAddress['address']['country'] = $_POST['shippingConsumerCountry'];
		$shippingAddress['address']['state'] = $_POST['shippingConsumerState'];
		$shippingAddress['address']['addressSuffix'] = $_POST['shippingConsumerAddressSuffix'];
	} else {
		$shippingAddress['name'] = $_POST['shippingCompanyName'];
		$shippingAddress['vatID'] = $_POST['shippingCompanyVat'];
		$shippingAddress['registry']['registryID'] = $_POST['shippingCompanyRegistryID'];
		$shippingAddress['registry']['zip'] = $_POST['shippingCompanyRegistryZIP'];
		$shippingAddress['registry']['city'] = $_POST['shippingCompanyRegistryCity'];			
		$shippingAddress['address']['street'] = $_POST['shippingCompanyStreet'];
		$shippingAddress['address']['houseNumber'] = $_POST['shippingCompanyHouseNumber'];
		$shippingAddress['address']['houseNumberSuffix'] = $_POST['shippingCompanyHouseNumberSuffix'];
		$shippingAddress['address']['zip'] = $_POST['shippingCompanyZIP'];
		$shippingAddress['address']['city'] = $_POST['shippingCompanyCity'];
		$shippingAddress['address']['country'] = $_POST['shippingCompanyCountry'];
		$shippingAddress['address']['state'] = $_POST['shippingCompanyState'];
		$shippingAddress['address']['addressSuffix'] = $_POST['shippingCompanyAddressSuffix'];
	} 
	
	$itemArr['shippingAddress'] = call_user_func('removeEmptyTag',$shippingAddress);
		
	// Billing Type and billing details		
	$billingType = ($_POST['billingType'] == 'billingConsumer')? 'consumer' : 'company';
	$itemArr['billingType'] = $billingType;
	
	if($billingType == 'consumer') {
		$billingAddress['salutation'] = $_POST['billingConsumerSalutation'];
		$billingAddress['title'] = $_POST['billingConsumerTitle'];
		$billingAddress['firstName'] = $_POST['billingConsumerFirstName'];
		$billingAddress['lastName'] = $_POST['billingConsumerLastName'];
		$billingAddress['maidenName'] = $_POST['billingConsumerMaidenName'];
		$billingAddress['gender'] = $_POST['billingConsumerGender'];
		$billingAddress['dateOfBirth'] = $_POST['billingConsumerDateOfBirth'];
		$billingAddress['language'] = $_POST['billingConsumerLanguage'];		
		$billingAddress['address']['street'] = $_POST['billingConsumerStreet'];
		$billingAddress['address']['houseNumber'] = $_POST['billingConsumerHouseNumber'];
		$billingAddress['address']['houseNumberSuffix'] = $_POST['billingConsumerHouseNumberSuffix'];
		$billingAddress['address']['zip'] = $_POST['billingConsumerZIP'];
		$billingAddress['address']['city'] = $_POST['billingConsumerCity'];
		$billingAddress['address']['country'] = $_POST['billingConsumerCountry'];
		$billingAddress['address']['state'] = $_POST['billingConsumerState'];
		$billingAddress['address']['addressSuffix'] = $_POST['billingConsumerAddressSuffix'];
	} else {
		$billingAddress['name'] = $_POST['billingCompanyName'];
		$billingAddress['vatID'] = $_POST['billingCompanyVat'];
		$billingAddress['registry']['registryID'] = $_POST['billingCompanyRegistryID'];
		$billingAddress['registry']['zip'] = $_POST['billingCompanyRegistryZIP'];
		$billingAddress['registry']['city'] = $_POST['billingCompanyRegistryCity'];			
		$billingAddress['address']['street'] = $_POST['billingCompanyStreet'];
		$billingAddress['address']['houseNumber'] = $_POST['billingCompanyHouseNumber'];
		$billingAddress['address']['houseNumberSuffix'] = $_POST['billingCompanyHouseNumberSuffix'];
		$billingAddress['address']['zip'] = $_POST['billingCompanyZIP'];
		$billingAddress['address']['city'] = $_POST['billingCompanyCity'];
		$billingAddress['address']['country'] = $_POST['billingCompanyCountry'];
		$billingAddress['address']['state'] = $_POST['billingCompanyState'];
		$billingAddress['address']['addressSuffix'] = $_POST['billingCompanyAddressSuffix'];
	} 
		
	$itemArr['billingAddress'] = call_user_func('removeEmptyTag',$billingAddress);
	
	$recurring['description'] = $_POST['recDescription'];
	$recurring['numberLimit'] = $_POST['recNumberLimit'];
	$recurring['amountLimit']['amount'] = $_POST['recAmount'];
	$recurring['amountLimit']['currency'] = $_POST['recCurrency'];
	$recurring['expireDate'] = $_POST['recExpireDate'];

	if (!empty($_POST['recAmount']) && !empty($_POST['recCurrency']) && empty($_POST['recRevokableByConsumer'])) {
		$recurring['revokableByConsumer'] = 'false';		
	} else {
		$recurring['revokableByConsumer'] = $_POST['recRevokableByConsumer'];
	}
	
	$itemArr['recurring'] = call_user_func('removeEmptyTag',$recurring);
	
	// Prepare items from Order Details
	for($i=1;$i<=3;$i++) {	
		$item = 'item'.$i;
		$itemType = $_POST[$item.'ItemType'];		
		$items[$i]['itemType'] = $itemType;	
	
		if($itemType == $item.'Text') {
			$items[$i]['textItemDescription'] = $_POST[$item.'TextItemDescription'];			
		} elseif($itemType == $item.'Item') {
			$items[$i]['itemDescription'] = $_POST[$item.'ItemDescription'];	
			$items[$i]['itemQuantity'] = $_POST[$item.'ItemQuantity'];	
			$items[$i]['itemUnitPriceAmount'] = $_POST[$item.'ItemUnitPriceAmount'];	
			$items[$i]['itemUnitPriceCurrency'] = $_POST[$item.'ItemUnitPriceCurrency'];	
			$items[$i]['itemTotalPriceAmount'] = $_POST[$item.'ItemTotalPriceAmount'];	
			$items[$i]['itemTotalPriceCurrency'] = $_POST[$item.'ItemTotalPriceCurrency'];				
		} elseif($itemType == $item.'Subtotal') {
			$items[$i]['subtotalItemDescription'] = $_POST[$item.'SubtotalItemDescription'];	
			$items[$i]['subtotalItemTotalPriceAmount'] = $_POST[$item.'SubtotalItemTotalPriceAmount'];	
			$items[$i]['subtotalItemTotalPriceCurrency'] = $_POST[$item.'SubtotalItemTotalPriceCurrency'];	
		} elseif($itemType == $item.'Vat') {
			$items[$i]['vatItemDescription'] = $_POST[$item.'VatItemDescription'];	
			$items[$i]['vatItemTotalPriceAmount'] = $_POST[$item.'VatItemTotalPriceAmount'];	
			$items[$i]['vatItemTotalPriceCurrency'] = $_POST[$item.'VatItemTotalPriceCurrency'];	
		} elseif($itemType == $item.'Total') {
			$items[$i]['totalItemDescription'] = $_POST[$item.'TotalItemDescription'];	
			$items[$i]['totalItemTotalPriceAmount'] = $_POST[$item.'TotalItemTotalPriceAmount'];	
			$items[$i]['totalItemTotalPriceCurrency'] = $_POST[$item.'TotalItemTotalPriceCurrency'];	
		}					
	}
		
	$items = call_user_func('removeEmptyTag',$items);	
	$itemArr['itemDetailList'] = $items;	  
	
	$_SESSION['payRequestItemList'][$batchID][$pos] = $itemArr;
}
header("Location: $redirectUrl");
exit();	
?>