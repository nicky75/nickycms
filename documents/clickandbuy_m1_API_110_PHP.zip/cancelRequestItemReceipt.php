<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

session_start();

$_SESSION['merchantID'] = $_POST['merchantID'];
$_SESSION['projectID'] = $_POST['projectID'];
$_SESSION['secretKey'] = $_POST['secretKey'];
	
$action = empty($_POST['action']) ? $_GET['action'] : $_POST['action']; 
$batchID = empty($_POST['batchID']) ? $_GET['batchID'] : $_POST['batchID'];
$itemNo = empty($_POST['itemNo']) ? $_GET['itemNo'] : $_POST['itemNo'];	

if (empty($batchID)) $batchID = 0;

// Check for API Version and choose redirect location
if(($_SESSION["apiVersion"]) == "1.0.0")
	$redirectUrl = 'cancelRequestBatch.php?batchID='.$batchID;
else if(($_SESSION["apiVersion"]) == "1.1.0")
	$redirectUrl = 'cancelRequestBatch110.php?batchID='.$batchID;
	
if($action == 'deleteItem') {
	unset($_SESSION['cancelItemList'][$batchID][$itemNo]);
} else {		
	$count = count($_SESSION['cancelItemList'][$batchID]);
	$pos = $count+1;		

	$itemArr['pos'] = $pos;
	$itemArr['batchItemExternalID'] = $_POST['batchItemExternalID'];
	$itemArr['cancelIdentifier']['transactionID'] = $_POST['transactionID'];
	$itemArr['cancelIdentifier']['rpaID'] = $_POST['rpaID'];
	$itemArr['cancelMode'] = $_POST['cancelMode'];
	
	$_SESSION['cancelItemList'][$batchID][$pos] = $itemArr;
}

header("Location: $redirectUrl");
exit();		
	
?>