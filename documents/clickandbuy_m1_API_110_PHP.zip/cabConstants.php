<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

// (Re-)Start Session
session_start(); 
 
// Merchant Account Settings
define("MERCHANT_ID",  "Please add your Merchant ID");
define("PROJECT_ID",  "Please add your Project ID");
define("SECRET_KEY",  "Please add your secret key");
define("MMS_SECRET_KEY",  "123456789");

// Activate/deactivate mms.log with true/false 
define("MMS_LOG", false);

// Email where the mms should be send e.g. mymail@your-domain.com
define("MMS_EMAIL_TO", "");

// Email from your server e.g. info@your-domain.com
define("MMS_EMAIL_FROM","info@your-domain.com");

// Location of the nusoap libraries for PHP4 support.
define("NUSOAP_FOLDER",  "lib/");

// Selector for SOAP connectivity to either the v1.0.0 or v1.1.0 API
if (isset($_SESSION["apiVersion"])) {
	if (($_SESSION["apiVersion"]) == "1.0.0") { // *** Add selection logic for v1.0.0
		define("SOAP_ENDPOINT",  "https://api.clickandbuy.com/webservices/soap/pay_1_0_0");
		define("SOAP_NAMESPACE",  "http://api.clickandbuy.com/webservices/pay_1_0_0/\" xmlns=\"http://api.clickandbuy.com/webservices/pay_1_0_0/");
		define("SOAP_ACTION",  "http://api.clickandbuy.com/webservices/pay_1_0_0/");
	} else if (($_SESSION["apiVersion"]) == "1.1.0") { // *** Add selection logic for v1.1.0
		define("SOAP_ENDPOINT",  "https://api.clickandbuy.com/webservices/soap/pay_1_1_0");
		define("SOAP_NAMESPACE",  "http://api.clickandbuy.com/webservices/pay_1_1_0/\" xmlns=\"http://api.clickandbuy.com/webservices/pay_1_1_0/");
		define("SOAP_ACTION",  "http://api.clickandbuy.com/webservices/pay_1_1_0/");
	}
}





?>