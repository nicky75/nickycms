<?php
	// Include Constants and Helper-Functions 
	include('cabConstants.php');	
	include('cabFunctions.php');	

	// (Re-)Start Session
	session_start();

	$batchID = $_GET['batchID'];	

	$merchantID = $_POST['merchantID'];
	$projectID = $_POST['projectID'];
	$secretKey = $_POST['secretKey'];

	$_SESSION['merchantID'] = $merchantID;
	$_SESSION['projectID'] = $projectID;
	$_SESSION['secretKey'] = $secretKey;
	
	$merchantID = !empty($_SESSION['merchantID']) ? $_SESSION['merchantID'] : MERCHANT_ID;
	$projectID = !empty($_SESSION['projectID']) ? $_SESSION['projectID'] : PROJECT_ID; 
	$secretKey = !empty($_SESSION['secretKey']) ? $_SESSION['secretKey'] : SECRET_KEY; 

	// Generate new "random" externalID on each page (re-)load
	$externalID = substr(md5(uniqid(rand())),0,12);  
?>
<html>
	<!-- Begin HTML Head -->
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
		<title>ClickandBuy - AddBatchItem Cancel (API v.1.1.0)</title>
		<link href="include/style.css" rel="stylesheet" type="text/css" />
		<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
	</head>
	<!-- begin HTML Body -->
	<body>
		<center>
			<table width="980" border="0" cellspacing="0" cellpadding="0">
				<tr>
					<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
					<td width="100%" align="center" class="headlogo">ClickandBuy - AddBatchItem Cancel (API v1.1.0)</td>
					<td align="right" valign="top" class="headlogo">
						<a href="index.php">Home</a>
					</td>
				</tr>
			</table>	
			<form action="cancelRequestItemReceipt.php" method="POST" >
				<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
					<tr>
						<td colspan="2" class="head1">Merchant Info</td>
					</tr>	    	
					<tr>
						<td width="50">&nbsp;</td>
						<td>
							<table width="680" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="200">Merchant ID:</td>
									<td><input type="text" name="merchantID" value="<?php echo $merchantID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
								</tr>		
								<tr>
									<td>Project ID:</td>
									<td><input type="text" name="projectID" value="<?php echo $projectID; ?>" onkeypress="return AllowNumericOnly(event);"/></td>
								</tr>		
								<tr>
									<td>Secret Key:</td>
									<td><input type="text" name="secretKey" value="<?php echo $secretKey; ?>" /></td>
								</tr>
							</table>&nbsp;
						</td>
					</tr>
					<tr>
						<td colspan="2" class="head1">Add Batch Item Details</td>
					</tr>	    	
					<tr>
						<td width="50">&nbsp;</td>
						<td>
							<table width="680" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="200">Batch ID:</td>
									<td><input type="text" name="batchID" value="<?php if ($batchID != 0) echo $batchID; ?>" /></td>
								</tr>		
								<tr>
									<td width="200">Batch Item External ID:</td>
									<td><input type="text" name="batchItemExternalID" value="" /></td>
								</tr>	    			
							</table>&nbsp;
						</td>
					</tr>    
					<tr>
						<td colspan="2" class="head1">Cancel Request Details  </td>
					</tr>
					<tr>
						<td width="50">&nbsp;</td>
						<td>
							<table width="680" border="0" cellspacing="0" cellpadding="0">
								<tr>
									<td width="200">Cancel Mode: </td>
									<td>
										<select name="cancelMode" size="1">
											<option value="TX">TX</option>
											<option value="RPA">RPA</option>
											<option value="BOTH">BOTH</option>
										</select>
									</td>
								</tr>
								<tr>
									<td width="200">Transaction ID: </td>
									<td><input type="text" name="transactionID" value="" /></td>
								</tr>
								<tr>
									<td width="200">RPA ID: </td>
									<td><input type="text" name="rpaID" value="" /></td>
								</tr>	    	
							</table>&nbsp;
						</td>
					</tr>
					<tr>
						<td width="50">&nbsp;</td>
						<td>
							<table width="680" border="0"" cellspacing="0" cellpadding="0">
								<tr>
									<td width="200">&nbsp;</td>
									<td><input type="submit" name="submit" value="Add Item to Batch List" /></td>
								</tr>
							</table>
						</td>
					</tr>   
				</table>
			</form>
			<?php if(!empty($_SESSION['cancelItemList'][$batchID])) {	?>
				<form action="cancelRequestBatchReceipt.php" method="POST" >
					<input type="hidden" name="batchID" value="<?=$batchID;?>" />
					<input type="hidden" name="merchantID" value="<?=$merchantID;?>" />
					<input type="hidden" name="projectID" value="<?=$projectID;?>" />
					<input type="hidden" name="secretKey" value="<?=$secretKey;?>" />
					<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
						<tr>
							<td colspan="2" class="head1">List of Batch Request Items</td>
						</tr>
						<tr>
							<td width="50">&nbsp;</td>
							<td>		
								<table width="680" border="0" cellspacing="0" cellpadding="0" class="cab_table">
									<tr>
										<td width="80"><strong>Item No</strong></td>
										<td width="120"><strong>Transaction ID</strong></td>
										<td width="120"><strong>RPA ID</strong></td>
										<td width="310"><strong>Cancel Mode</strong></td>
										<td width="50"><strong>Action</strong></td>
									</tr>
									<?php foreach($_SESSION['cancelItemList'][$batchID] as $key) { ?>
									<tr>
										<td><?=$key['pos'];?></td>
										<td><?=$key['cancelIdentifier']['transactionID'];?></td>
										<td><?=$key['cancelIdentifier']['rpaID'];?></td>
										<td><?=$key['cancelMode'];?></td>
										<td><a href="cancelRequestItemReceipt.php?action=deleteItem&batchID=<?=$batchID;?>&itemNo=<?=$key['pos'];?>">Delete</a></td>
									</tr>
									<?php } ?>
								</table>&nbsp;
							</td>
						</tr>    
						<tr>
							<td width="50">&nbsp;</td>
							<td>
								<table width="680" border="0"" cellspacing="0" cellpadding="0">
									<tr>
										<td width="200">&nbsp;</td>
										<td><input type="submit" name="submit" value="Add to Batch" /></td>
									</tr>
								</table>
							</td>
						</tr> 
					</table>
				</form>
			<?php } ?>	
		</center>
	</body>
</html>