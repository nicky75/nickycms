<?php
/**
 * ClickandBuy Sample PHP Script 
 * Code by PayIntelligent GmbH  <http://www.payintelligent.de/>
 * Sponsored by ClickandBuy <http://www.clickandbuy.com/>
 */

session_start();

$errorResult = $_SESSION['error_result'];
$reqName = $errorResult['req_name'];
$error = $errorResult['error'];
$faultcode = $errorResult['faultcode'];
$faultstring = $errorResult['faultstring']['!'];
$request = $errorResult['request'];
$response = $errorResult['response'];
$display = 'none';

$errDetailcode = $errorResult['values']['detail']['errorDetails']['detailCode'];
$errDescription= $errorResult['values']['detail']['errorDetails']['description'];

?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <title>ClickandBuy - Error</title>
  <link href="include/style.css" rel="stylesheet" type="text/css" />
	<script src="include/general.js" type="text/javascript" charset="utf-8"></script>
</head>
<body>

<center>
<table width="980" border="0" cellspacing="0" cellpadding="0">
<tr>
	<td align="left"><img src="images/logo_header.gif" title="ClickandBuy" /></td>
	<td width="100%" align="center" class="headlogo">ClickandBuy - Error</td>
	<td align="right" valign="top" class="headlogo">
		<a href="index.php">Home</a>
	</td>
</tr>
</table>		

<table width="980" border="0" cellspacing="0" cellpadding="0" class="cab_table">
<tr>
	<td colspan="2" class="head1">PayRequest Result</td>
</tr>	    	
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<table width="680" border="0" cellspacing="0" cellpadding="0">
    <tr>
    	<td colspan="2" class="result_suc">An error occurred</td>
    </tr>		
    <tr>
    	<td width="200">Method:</td>
    	<td><?php echo $reqName; ?></td>
    </tr>		
    <?php if ($errorResult['error_type'] == 'fault') { ?>
    <tr>
	    <td>Fault Code:</td>
	    <td><?php echo $faultcode; ?></td>
    </tr>
    <tr>
	    <td>Fault String:</td>
	    <td><?php echo $faultstring; ?></td>
    </tr>
    <tr>
	    <td>Error code:</td>
	    <td><?php echo $errDetailcode; ?></td>
    </tr>
    <tr>
	    <td>Error Description:</td>
	    <td><?php echo $errDescription; ?></td>
    </tr>
    <?php } else { ?>
    <tr>
	    <td>Error:</td>
	    <td><?php echo $error; ?></td>
    </tr>
<?php } ?>	    			    
    </table>&nbsp;
	</td>
</tr>
<tr>
	<td colspan="2" class="head1">SOAP Request &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox1" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
		<tr>
			<td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$request.'</textarea>'; ?></td>
	    <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox1'); return false" title="Hide">Hide</a></td>
		</tr>   
	  </table>
	  </div>&nbsp;
	</td>
</tr>    
<tr>
	<td colspan="2" class="head1">SOAP Response &gt;&gt; <a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Show">Show</a></td>
</tr>
<tr>
	<td width="50">&nbsp;</td>
	<td>
		<div id="divbox2" style="display:none">			
		<table width="680" border="0"" cellspacing="0" cellpadding="0">
    <tr>
	    <td><?php echo '<textarea readonly name="request" cols="80" rows="25">'.$response.'</textarea>'; ?></td>
	    <td width="40" align="right" valign="top"><a href="#" onClick="javascript:toggledisplay('divbox2'); return false" title="Hide">Hide</a></td>
		</tr>   
	  </table>
	  </div>&nbsp;
	</td>
</tr>    
</table>	
</center>

</body>
</html>

